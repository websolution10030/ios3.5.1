//
//  AppDelegate.h
//  EduClass
//
//  Created by lyy on 2018/4/17.
//  Copyright © 2018年 talkcloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (assign, nonatomic) UIInterfaceOrientationMask orientationStatus;

+ (AppDelegate *) appDelegate;

@end

