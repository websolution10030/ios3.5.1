//
//  TKNavigationController.h
//  EduClassPad
//
//  Created by ifeng on 2017/5/10.
//  Copyright © 2017年 beijing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TKNavigationController : UINavigationController
@property (nonatomic,strong) UILabel *titleLabel;
@end
