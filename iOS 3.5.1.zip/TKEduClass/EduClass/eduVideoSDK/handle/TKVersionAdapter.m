//
//  TKVersionAdapter.m
//  EduClass
//
//  Created by 周洁 on 2020/3/27.
//  Copyright © 2020 talkcloud. All rights reserved.
//

#import "TKVersionAdapter.h"
static TKVersionAdapter *adapter = nil;
@implementation TKVersionAdapter
{
    NSMutableDictionary <NSString *, NSMutableSet *> *_userDic;
    NSMutableDictionary <NSString *, NSMutableSet *> *_userConsumeDic;
}

+ (instancetype)sharedInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!adapter) {
            adapter = [[TKVersionAdapter alloc] init];
        }
    });
    
    return adapter;
}

- (instancetype)init
{
    if (self = [super init]) {
        _userDic = [NSMutableDictionary dictionary];
        _userConsumeDic = [NSMutableDictionary dictionary];
    }
    
    return self;
}

- (void)addUser:(TKRoomUser *)user
{
    if (!user) {
        return;
    }
    NSString *tkversion = user.properties[sTKVersion] ? user.properties[sTKVersion] : @"0";
    NSMutableSet *set = [_userDic objectForKey:tkversion];
    if (!set) {
        set = [NSMutableSet set];
    }
    
    [set addObject:user];
    [_userDic setObject:set forKey:tkversion];
    
    
    if (user.role == TKUserType_Student) {
        
        NSString *consume = user.properties[sTKLowConsume] ? user.properties[sTKLowConsume] : @"0";
        NSMutableSet * lowset = [_userConsumeDic objectForKey:consume];
        if (!lowset) {
            lowset = [NSMutableSet set];
        }
        [lowset addObject:user];
        [_userConsumeDic setObject:lowset forKey:consume];
    }
}

- (void)deleteUser:(TKRoomUser *)user
{
    if (!user) {
        return;
    }

    if (_userDic.count<=0) {
        return;
    }

    NSString *tkversion = user.properties[sTKVersion] ? user.properties[sTKVersion] : @"0";
    NSMutableSet *set = [_userDic objectForKey:tkversion];
    
    if (!set) {
        return;
    }
    [set removeObject:user];

    [_userDic setObject:set forKey:tkversion];
    

    
    if (user.role == TKUserType_Student) {
        
        NSString *consume = user.properties[sTKLowConsume] ? user.properties[sTKLowConsume] : @"0";
        NSMutableSet *lowset = [_userConsumeDic objectForKey:consume];
        if (lowset) {
            [lowset removeObject:user];
            [_userConsumeDic setObject:lowset forKey:consume];
        }
        
    }

}

- (void)removeAllUser
{
    [_userDic removeAllObjects];
    [_userConsumeDic removeAllObjects];
}

- (BOOL)containsTKVersionNumber:(NSString *)tkversion
{
    NSMutableSet *set = [_userDic objectForKey:tkversion];
    return (set.count > 0);
}

- (BOOL)containsTKVersionBelowNumber:(NSString *)tkversion
{
    __block BOOL contains = NO;
    [_userDic enumerateKeysAndObjectsUsingBlock:^(NSString * _Nonnull key, NSMutableSet * _Nonnull obj, BOOL * _Nonnull stop) {
        if (key.intValue < tkversion.intValue) {
            if (obj.count > 0) {
                contains = YES;
                *stop = YES;
            }
        }
    }];
    
    return contains;
}

- (BOOL)containsStudentTKVersionBelowNumber:(NSString *)tkversion
{
    __block BOOL contains = NO;
    [_userDic enumerateKeysAndObjectsUsingBlock:^(NSString * _Nonnull key, NSMutableSet * _Nonnull obj, BOOL * _Nonnull stop) {
        if (key.intValue < tkversion.intValue) {
            if (obj.count > 0) {
                for (TKRoomUser * user in obj) {
                    if (user.role == TKUserType_Student) {
                        
                        contains = YES;
                        *stop = YES;
                    }
                }
            }
        }
    }];
    
    return contains;
}

- (NSSet *) getStudentTKVersionBelowNumber:(NSString *)tkversion {
    
    __block NSMutableSet * userSet = [[NSMutableSet alloc] init];
    [_userDic enumerateKeysAndObjectsUsingBlock:^(NSString * _Nonnull key, NSMutableSet * _Nonnull obj, BOOL * _Nonnull stop) {
        if (key.intValue < tkversion.intValue) {
            for (TKRoomUser * user in obj) {
                if (user.role == TKUserType_Student) {
                    [userSet addObject:user];
                }
            }
        }
    }];
    
    return [NSSet setWithSet:userSet];
}

- (BOOL)containsLowConsume;
{
    return [_userConsumeDic objectForKey:@"0"].count > 0 ? YES : NO;
}

- (NSSet *) getUserUseLowConsume {
    
    return [[_userConsumeDic objectForKey:@"0"] copy];
}

@end
