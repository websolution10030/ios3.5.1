//
//  TKVersionAdapter.h
//  EduClass
//
//  Created by 周洁 on 2020/3/27.
//  Copyright © 2020 talkcloud. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TKVersionAdapter : NSObject

+ (instancetype)sharedInstance;

- (void)addUser:(TKRoomUser *)user;

- (void)deleteUser:(TKRoomUser *)user;

- (void)removeAllUser;

/**
@discussion 教室里是否存在 tkversion 版本的用户
*/
- (BOOL)containsTKVersionNumber:(NSString *)tkversion;


/**
@discussion 教室里是否存在低于 tkversion 版本的用户
*/
- (BOOL)containsTKVersionBelowNumber:(NSString *)tkversion;

/**
@discussion 教室里是否存在低于 tkversion 版本的学生用户
*/
- (BOOL)containsStudentTKVersionBelowNumber:(NSString *)tkversion;

/**
@discussion 获取教室内低于 tkversion 版本的用户
*/
- (NSSet *) getStudentTKVersionBelowNumber:(NSString *)tkversion;

/**
@discussion 教室里是否存在 使用低耗设备的用户
*/
- (BOOL)containsLowConsume;

/**
@discussion 获取教室使用低耗设备的用户
*/
- (NSSet *) getUserUseLowConsume;
@end

NS_ASSUME_NONNULL_END
