//
//  TKManyViewController+MiniWhiteBoard.h
//  EduClass
//
//  Created by Yibo on 2019/4/2.
//  Copyright © 2019 talkcloud. All rights reserved.
//

#import "TKOneViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface TKOneViewController (MiniWhiteBoard)

- (void)miniWBRecoveryAfterGetinClass:(NSNotification *)notification;

@end

NS_ASSUME_NONNULL_END
