//
//  TKOneViewController+Media.h
//  EduClass
//
//  Created by maqihan on 2018/11/21.
//  Copyright © 2018 talkcloud. All rights reserved.
//

#import "TKOneViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface TKOneViewController (Media)

- (void)closeMediaView;

@end

NS_ASSUME_NONNULL_END
