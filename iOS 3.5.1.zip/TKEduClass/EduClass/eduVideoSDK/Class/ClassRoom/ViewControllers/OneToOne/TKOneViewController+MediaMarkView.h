//
//  TKManyViewController+MediaMarkView.h
//  EduClass
//
//  Created by Yibo on 2019/4/9.
//  Copyright © 2019 talkcloud. All rights reserved.
//

#import "TKOneViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface TKOneViewController (MediaMarkView)
- (void)mediaMarkRecoveryAfterGetinClass:(NSNotification *)notification;
@end

NS_ASSUME_NONNULL_END
