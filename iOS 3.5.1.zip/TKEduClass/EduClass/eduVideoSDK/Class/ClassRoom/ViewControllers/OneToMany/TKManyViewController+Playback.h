//
//  TKManyViewController+Playback.h
//  EduClass
//
//  Created by Yi on 2018/11/19.
//  Copyright © 2018年 talkcloud. All rights reserved.
//

#import "TKManyViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface TKManyViewController (Playback)


- (void)initPlaybackMaskView;


@end

NS_ASSUME_NONNULL_END
