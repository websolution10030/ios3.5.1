//
//  TKManyViewController+MediaMarkView.h
//  EduClass
//
//  Created by Yibo on 2019/4/9.
//  Copyright © 2019 talkcloud. All rights reserved.
//

#import "TKManyViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface TKManyViewController (MediaMarkView)
- (void)mediaMarkRecoveryAfterGetinClass:(NSNotification *)notification;
@end

NS_ASSUME_NONNULL_END
