//
//  TKPageButton.h
//  EduClass
//
//  Created by lyy on 2018/4/19.
//  Copyright © 2018年 talkcloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TKPageButton : UIButton

+ (instancetype)pageButton;

@end
