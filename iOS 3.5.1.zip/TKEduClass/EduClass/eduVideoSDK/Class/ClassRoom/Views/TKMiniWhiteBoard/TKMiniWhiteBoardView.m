//
//  TKMiniWhiteBoardView.m
//  TKWhiteBoard
//
//  Created by 周洁 on 2019/1/7.
//  Copyright © 2019 MAC-MiNi. All rights reserved.
//

#import "TKMiniWhiteBoardView.h"
#import "Masonry.h"
#import <TKRoomSDK/TKRoomSDK.h>

/*
 小白板业务逻辑：
 老师端：老师点击小白板时发送_prepareing信令，在收到_prepareing信令时显示小白板。
 _prepareing状态下老师的所有绘制需要同步到学生端的所有学生画布以及老师画布。
 老师点击小白板分发按钮时发送_dispenseed信令，在收到_dispenseed信令时开始显示导航栏。
 _dispenseed状态下老师只能在自己画布上绘制，此时老师可以任意切换导航，老师在自己画布上的绘制需要同步到所有学生。
 老师点击回收按钮发送_recycle信令，在收到_recycle信令时切换到_recycle状态，此状态下老师可以自由切换导航并且在任意画布上绘制。
 老师点击再次分发按钮时发送_againDispenseed信令，在收到_againDispenseed时切换到_againDispenseed状态，该状态下只能在自己画布上绘制，并且可以任意切换导航
 老师切换导航发送信令，信令包括状态和切换的id，切换学生时id为学生的peerid，切换到老师时id为blackboardcommmon。
 学生端：收到_prepareing信令时不展示，随后收到老师端isBaseboard=YES绘制信息时需要保存所有isBaseboard=YES绘制数据到prepareData数组。
 收到_dispenseed信令时切换drawView工作模式到controller并且显示画笔工具栏，此状态下可以在自己画布上绘制并同步
 收到_recycle信令时切换drawView工作模式到viewer此时无法绘制并隐藏画笔工具
 收到_againDispenseed信令时切换drawView工作模式到controller此时可以在自己画布上绘制，此绘制要同步到所有学生端对应的画布上，并显示画笔工具和导航，但学生始终无法主动切换画布，_againDispenseed信令中包含切换到的id，学生端导航和画笔都要切换到此id上。

 UserHasNewBlackBoard信令：学生端和老师端收到此信令表示有新的角色进入，老师和学生（学生隐藏了导航）都要在导航上添加此角色。导航排序方式:老师总是排第一位，后面的学生按照peerid排序。添加此角色后需要将此前保存的prepareData数据恢复到这个画布上(老师端学生端都需要做恢复)。
 
 上传图片:选中图片上传之后在教室里面收到地址并发送sMiniBlackBoard_upload信令，小白板收到sMiniBlackBoard_upload信令就开始拼接地址加载图片。
 
 进教室恢复数据：TKOne/ManyViewController+MiniWhiteBoard中用来处理进教室收到的缓存信令，使用handleSignal直接处理这些信令就能完成同步。
 */

#define ThemeKP(args) [@"TKNativeWB.LightWB." stringByAppendingString:args]

@implementation TKMiniWhiteBoardView
{
    UIButton *_closeBtn;
    UIView *_drawToolView;
    UIView *_underDrawView;
    
    UIButton *_penBtn;
    UIButton *_textBtn;
    UIButton *_eraserBtn;
    
    UIButton *_sendBtn;
    UIPanGestureRecognizer *_panG;
    
    NSMutableArray <NSDictionary *> *_prepareData;
    
    UIImageView *_imageView;
    UIButton *_uploadBtn;

    UIView *_uploadIslandView;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (instancetype)init
{
    if (self = [super init]) {
        _prepareData = [@[] mutableCopy];
        
        self.sakura.backgroundColor(ThemeKP(@"bg_color"));
        self.layer.masksToBounds = YES;
        self.layer.cornerRadius = 10 * Proportion;
        
        _closeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _closeBtn.sakura.backgroundImage(ThemeKP(@"tk_close"), UIControlStateNormal);
        [self addSubview:_closeBtn];
        [_closeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.mas_right).offset(-10 * Proportion);
            make.top.equalTo(self.mas_top).offset(10 * Proportion);
            make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(20 * Proportion, 20 * Proportion)]);
        }];
        
        [_closeBtn addTarget:self action:@selector(closeMiniWhiteBoard) forControlEvents:UIControlEventTouchUpInside];
        
        _segmentCotnrol = [[TKStudentSegmentControl alloc] initWithDelegate:self];
        [self addSubview:_segmentCotnrol];
        [_segmentCotnrol mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.mas_left).offset(5 * Proportion);
            make.top.equalTo(self.mas_top).offset(5 * Proportion);
            make.height.equalTo(@((37 + 10) * Proportion));
            make.right.equalTo(self.mas_right).offset(-96 * Proportion);
        }];
        
        _underDrawView = [[UIView alloc] init];
        _underDrawView.sakura.backgroundColor(ThemeKP(@"tip_bg_sel_color"));
        [self addSubview:_underDrawView];
        [_underDrawView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.mas_left).offset(5 * Proportion).priorityHigh();
            make.right.equalTo(self.mas_right).offset(-5 * Proportion).priorityHigh();
            make.top.equalTo(self.mas_top).offset(42 * Proportion).priorityHigh();
            make.bottom.equalTo(self.mas_bottom).offset(-53 * Proportion).priorityHigh();
            make.width.equalTo(_underDrawView.mas_height).multipliedBy(16 / 9.0f).priorityHigh();
        }];
        
        _imageView = [[UIImageView alloc] init];
        [_imageView setContentHuggingPriority:UILayoutPriorityFittingSizeLevel forAxis:UILayoutConstraintAxisHorizontal];
        [_imageView setContentCompressionResistancePriority:UILayoutPriorityFittingSizeLevel forAxis:UILayoutConstraintAxisHorizontal];
        [_imageView setContentHuggingPriority:UILayoutPriorityFittingSizeLevel forAxis:UILayoutConstraintAxisVertical];
        [_imageView setContentCompressionResistancePriority:UILayoutPriorityFittingSizeLevel forAxis:UILayoutConstraintAxisVertical];
        _imageView.hidden = YES;
        [self addSubview:_imageView];
        
        _tkDrawView = [[TKDrawView alloc] initWithDelegate:self];
        [_tkDrawView setWorkMode:TKWorkModeControllor];
        [_tkDrawView switchToFileID:sBlackBoardCommon pageID:1 refreshImmediately:YES];
        [self addSubview:_tkDrawView];
        [_tkDrawView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(_underDrawView.mas_left);
            make.right.equalTo(_underDrawView.mas_right);
            make.top.equalTo(_underDrawView.mas_top);
            make.bottom.equalTo(_underDrawView.mas_bottom);
        }];
        
        TKStudentSegmentObject *teacher = [[TKStudentSegmentObject alloc] init];
        teacher.ID = sBlackBoardCommon;
        teacher.currentPage = 1;
        teacher.seq = @(0);
        _choosedStudent = teacher;
        
        _drawToolView = [[UIView alloc] init];
        [self addSubview:_drawToolView];
        
        _penBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _penBtn.sakura.backgroundImage(ThemeKP(@"tk_pen_swb_default"), UIControlStateNormal);
        _penBtn.sakura.backgroundImage(ThemeKP(@"tk_pen_swb_selected"), UIControlStateSelected);
        [_penBtn addTarget:self action:@selector(drawPen:) forControlEvents:UIControlEventTouchUpInside];
        _penBtn.selected = YES;
        [_drawToolView addSubview:_penBtn];
        [_penBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(_drawToolView.mas_left);
            make.centerY.equalTo(_drawToolView.mas_centerY);
            make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(39 * Proportion, 25 * Proportion)]);
        }];
        
        _textBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _textBtn.sakura.backgroundImage(ThemeKP(@"tk_text_swb_default"), UIControlStateNormal);
        _textBtn.sakura.backgroundImage(ThemeKP(@"tk_text_swb_selected"), UIControlStateSelected);
        [_textBtn addTarget:self action:@selector(drawText:) forControlEvents:UIControlEventTouchUpInside];
        [_drawToolView addSubview:_textBtn];
        [_textBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(_penBtn.mas_right).offset(40 * Proportion);
            make.centerY.equalTo(_drawToolView.mas_centerY);
            make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(39 * Proportion, 25 * Proportion)]);
        }];
        
        _eraserBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _eraserBtn.sakura.backgroundImage(ThemeKP(@"tk_xiangpi_swb_default"), UIControlStateNormal);
        _eraserBtn.sakura.backgroundImage(ThemeKP(@"tk_xiangpi_swb_selected"), UIControlStateSelected);
        [_eraserBtn addTarget:self action:@selector(drawEraser:) forControlEvents:UIControlEventTouchUpInside];
        [_drawToolView addSubview:_eraserBtn];
        [_eraserBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(_textBtn.mas_right).offset(40 * Proportion);
            make.centerY.equalTo(_drawToolView.mas_centerY);
            make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(39 * Proportion, 25 * Proportion)]);
        }];
        
        _uploadBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _uploadBtn.sakura.backgroundImage(ThemeKP(@"upload_default"), UIControlStateNormal);
        _uploadBtn.sakura.backgroundImage(ThemeKP(@"upload_selected"), UIControlStateSelected);
        [_uploadBtn addTarget:self action:@selector(upload:) forControlEvents:UIControlEventTouchUpInside];
        [_drawToolView addSubview:_uploadBtn];
        [_uploadBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(_eraserBtn.mas_right).offset(40 * Proportion);
            make.centerY.equalTo(_drawToolView.mas_centerY);
            make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(39 * Proportion, 25 * Proportion)]);
        }];

        //注释下面代码即可打开学生小白板上传功能
        _uploadBtn.hidden = [TKRoomManager instance].localUser.role != TKUserType_Teacher;
        
        [_drawToolView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.mas_left).offset(31 * Proportion);
            make.right.equalTo(_uploadBtn.mas_right);
            make.top.equalTo(_tkDrawView.mas_bottom);
            make.bottom.equalTo(self.mas_bottom);
        }];
        
        _selectorView = [[TKBrushSelectorView alloc] initWithDefaultColor:nil];
        _selectorView.clipsToBounds = YES;
        _selectorView.delegate = self;
        
        _sendBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _sendBtn.sakura.backgroundImage(ThemeKP(@"tk_button_send_default"), UIControlStateNormal);
        [_sendBtn addTarget:self action:@selector(sendState) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_sendBtn];
        [_sendBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.mas_right).offset(-12 * Proportion);
            make.bottom.equalTo(self.mas_bottom).offset(-4 * Proportion);
            make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(115 * Proportion, 44 * Proportion)]);
        }];
        
        _panG = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panGesture:)];
        [self addGestureRecognizer:_panG];
                
        [self setNeedsLayout];
        [self layoutIfNeeded];
    }
    
    return self;
}

- (void)didMoveToSuperview
{
    [super didMoveToSuperview];
    self.fakeView = [[TKMiniWhiteBoardFakeView alloc] initWithFrame:self.superview.frame];
    self.fakeView.backgroundColor = UIColor.clearColor;
    self.fakeView.miniWB = self;
    [self.superview insertSubview:self.fakeView belowSubview:self];
}

- (void)panGesture:(UIPanGestureRecognizer *)panG
{
    CGPoint translatedPoint = [panG translationInView:self];
    CGFloat x = self.center.x + translatedPoint.x;
    CGFloat y = self.center.y + translatedPoint.y;
    if (panG.state == UIGestureRecognizerStateBegan) {
        if (CGRectContainsPoint(_tkDrawView.frame, [panG locationInView:self])) {
            panG.enabled = NO;
        }
    } else if (panG.state == UIGestureRecognizerStateChanged) {

        CGPoint deltaCenter = CGPointMake(x - self.superview.frame.size.width / 2, y - self.superview.frame.size.height / 2);
        
        [self mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.left.greaterThanOrEqualTo(self.moveableUnderView.mas_left).priorityHigh();
            make.right.lessThanOrEqualTo(self.moveableUnderView.mas_right).priorityHigh();
            make.bottom.greaterThanOrEqualTo(self.moveableUnderView.mas_bottom).priorityHigh();
            make.top.lessThanOrEqualTo(self.moveableUnderView.mas_top).priorityHigh();
            make.centerX.equalTo(self.superview.mas_centerX).offset(deltaCenter.x).priorityLow();
            make.centerY.equalTo(self.superview.mas_centerY).offset(deltaCenter.y).priorityLow();
            make.width.equalTo(@(self.frame.size.width));
            make.height.equalTo(@(self.frame.size.height));
        }];
    }
    
    [panG setTranslation:CGPointMake(0, 0) inView:self];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    //设定白板相对web比例
    _tkDrawView.scale = _tkDrawView.frame.size.height / 960;
}

- (void)setDefaultDrawData
{
    if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Teacher || [TKEduSessionHandle shareInstance].localUser.role == TKUserType_Playback) {
        [_tkDrawView setDrawType:TKDrawTypePen hexColor:@"#ED3E3A" progress:0.05f];
    }
    
    if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
        [_tkDrawView setDrawType:TKDrawTypePen hexColor:@"#160C30" progress:0.05f];
    }
}

- (void)sendStudent
{
    if (self.isBigRoom) {
        //大并发教室自己未上台则不发自己
        if ([TKEduSessionHandle shareInstance].localUser.publishState == 0) {
            return;
        }
    }
    
    if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
        __block BOOL has = NO;
        [_segmentCotnrol.students enumerateObjectsUsingBlock:^(TKStudentSegmentObject * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            if ([obj.ID isEqualToString:[TKEduSessionHandle shareInstance].localUser.peerID]) {
                has = YES;
            }
        }];
        if (!has) {
            
            NSDictionary * pubDict = @{@"id" : [TKEduSessionHandle shareInstance].localUser.peerID,
                                       @"nickname" : [TKEduSessionHandle shareInstance].localUser.nickName, @"role" : @(2)};
            [[TKEduSessionHandle shareInstance] sessionHandlePubMsg:sUserHasNewBlackBoard
                                                                 ID:[NSString stringWithFormat:@"_%@",[TKEduSessionHandle shareInstance].localUser.peerID]
                                                                 To:sTellAll
                                                               Data:pubDict
                                                               Save:YES
                                                    AssociatedMsgID:sBlackBoard_new
                                                   AssociatedUserID:[TKEduSessionHandle shareInstance].localUser.peerID
                                                            expires:0
                                                         completion:nil];
        }
    }
}

//接收状态
- (void)switchStates:(TKMiniWhiteBoardState)state
{
    if (![_tkDrawView hasDraw]) {
        [self setDefaultDrawData];
    }
    self.state = state;
    switch (state) {
        case TKMiniWhiteBoardStatePrepareing:
        {
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
                _segmentCotnrol.hidden = YES;
                _closeBtn.hidden = YES;
                _sendBtn.hidden = YES;
                _drawToolView.hidden = NO;
                _segmentCotnrol.userInteractionEnabled = NO;
            }
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Teacher) {
                _segmentCotnrol.hidden = YES;
                _closeBtn.hidden = NO;
                _sendBtn.hidden = NO;
                _drawToolView.hidden = NO;
                _uploadBtn.enabled = YES;
                _segmentCotnrol.userInteractionEnabled = YES;
                
                NSDictionary * pubDict = @{@"id" : sBlackBoardCommon, @"nickname" : [TKEduSessionHandle shareInstance].localUser.nickName, @"role" : @(0)};
                [[TKEduSessionHandle shareInstance] sessionHandlePubMsg:sUserHasNewBlackBoard
                                                                     ID:[NSString stringWithFormat:@"_%@",[TKEduSessionHandle shareInstance].localUser.peerID]
                                                                     To:sTellAll
                                                                   Data:pubDict
                                                                   Save:YES
                                                        AssociatedMsgID:sBlackBoard_new
                                                       AssociatedUserID:sBlackBoardCommon
                                                                expires:0
                                                             completion:nil];
            }
            
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Patrol) {
                _segmentCotnrol.hidden = YES;
                _closeBtn.hidden = YES;
                _sendBtn.hidden = YES;
                _drawToolView.hidden = YES;
                _segmentCotnrol.userInteractionEnabled = _drawToolView.userInteractionEnabled = _sendBtn.userInteractionEnabled = _closeBtn.userInteractionEnabled = _segmentCotnrol.userInteractionEnabled = NO;
            }
            
            [_sendBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:TKMTLocalized(@"MiniWB.Dispense") attributes:@{NSForegroundColorAttributeName : UIColor.whiteColor, NSFontAttributeName : [UIFont systemFontOfSize:16 * Proportion]}] forState:UIControlStateNormal];

            break;
        }
        case TKMiniWhiteBoardStateDispenseed:
        {
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
                 _segmentCotnrol.hidden = YES;
                _drawToolView.hidden = NO;
                _sendBtn.hidden = YES;
                _closeBtn.hidden = YES;
                _segmentCotnrol.userInteractionEnabled = NO;
                [self sendStudent];
            }
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Teacher) {
                _segmentCotnrol.hidden = NO;
                _drawToolView.hidden = NO;
                _sendBtn.hidden = NO;
                _closeBtn.hidden = NO;
                _segmentCotnrol.userInteractionEnabled = YES;
                _uploadBtn.enabled = NO;
            }
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Patrol) {
                _segmentCotnrol.hidden = NO;
                _drawToolView.hidden = YES;
                _sendBtn.hidden = YES;
                _closeBtn.hidden = YES;
                _segmentCotnrol.userInteractionEnabled = _drawToolView.userInteractionEnabled = _sendBtn.userInteractionEnabled = _closeBtn.userInteractionEnabled = _segmentCotnrol.userInteractionEnabled = NO;
            }
            
            [_sendBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:TKMTLocalized(@"MiniWB.Recycle") attributes:@{NSForegroundColorAttributeName : UIColor.whiteColor, NSFontAttributeName : [UIFont systemFontOfSize:16 * Proportion]}] forState:UIControlStateNormal];
            
            break;
        }
        case TKMiniWhiteBoardStateAgainDispenseed:
        {
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
                _segmentCotnrol.hidden = YES;
                _drawToolView.hidden = NO;
                _sendBtn.hidden = YES;
                _closeBtn.hidden = YES;
                _segmentCotnrol.userInteractionEnabled = NO;
                [self sendStudent];
            }
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Teacher) {
                _segmentCotnrol.hidden = NO;
                _drawToolView.hidden = NO;
                _sendBtn.hidden = NO;
                _closeBtn.hidden = NO;
                _segmentCotnrol.userInteractionEnabled = YES;
                _uploadBtn.enabled = NO;
            }
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Patrol) {
                _segmentCotnrol.hidden = NO;
                _drawToolView.hidden = YES;
                _sendBtn.hidden = YES;
                _closeBtn.hidden = YES;
                _segmentCotnrol.userInteractionEnabled = _drawToolView.userInteractionEnabled = _sendBtn.userInteractionEnabled = _closeBtn.userInteractionEnabled = _segmentCotnrol.userInteractionEnabled = NO;
            }
            
            [_sendBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:TKMTLocalized(@"MiniWB.Recycle") attributes:@{NSForegroundColorAttributeName : UIColor.whiteColor, NSFontAttributeName : [UIFont systemFontOfSize:16 * Proportion]}] forState:UIControlStateNormal];
            break;
        }
        case TKMiniWhiteBoardStateRecycle:
        {
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
                _segmentCotnrol.hidden = NO;
                _drawToolView.hidden = YES;
                _sendBtn.hidden = YES;
                _closeBtn.hidden = YES;
                _segmentCotnrol.userInteractionEnabled = NO;
                [self sendStudent];
            }
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Teacher) {
                _segmentCotnrol.hidden = NO;
                _drawToolView.hidden = NO;
                _sendBtn.hidden = NO;
                _closeBtn.hidden = NO;
                _segmentCotnrol.userInteractionEnabled = YES;
            }
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Patrol) {
                _segmentCotnrol.hidden = NO;
                _drawToolView.hidden = YES;
                _sendBtn.hidden = YES;
                _closeBtn.hidden = YES;
                _segmentCotnrol.userInteractionEnabled = YES;
                _segmentCotnrol.userInteractionEnabled = _drawToolView.userInteractionEnabled = _sendBtn.userInteractionEnabled = _closeBtn.userInteractionEnabled = _segmentCotnrol.userInteractionEnabled = NO;
            }

            [_sendBtn setAttributedTitle:[[NSAttributedString alloc] initWithString:TKMTLocalized(@"MiniWB.Redispense") attributes:@{NSForegroundColorAttributeName : UIColor.whiteColor, NSFontAttributeName : [UIFont systemFontOfSize:16 * Proportion]}] forState:UIControlStateNormal];
            break;
        }
        
        default:
            break;
    }
}

//老师点击按钮发送状态
- (void)sendState
{
    switch (self.state) {
        case TKMiniWhiteBoardStateDispenseed:
        {
            [[TKEduSessionHandle shareInstance] sessionHandlePubMsg:sBlackBoard_new ID:sBlackBoard_new To:sTellAll Data:@{@"blackBoardState" : @"_recycle", @"currentTapKey" : sBlackBoardCommon, @"currentTapPage" : @(1)} Save:YES AssociatedMsgID:sClassBegin AssociatedUserID:nil expires:0 completion:nil];
            break;
        }
        case TKMiniWhiteBoardStateAgainDispenseed:
        {
            [[TKEduSessionHandle shareInstance] sessionHandlePubMsg:sBlackBoard_new ID:sBlackBoard_new To:sTellAll Data:@{@"blackBoardState" : @"_recycle", @"currentTapKey" : sBlackBoardCommon, @"currentTapPage" : @(1)} Save:YES AssociatedMsgID:sClassBegin AssociatedUserID:nil expires:0 completion:nil];
            break;
        }
        case TKMiniWhiteBoardStateRecycle:
        {
            [[TKEduSessionHandle shareInstance] sessionHandlePubMsg:sBlackBoard_new ID:sBlackBoard_new To:sTellAll Data:@{@"blackBoardState" : @"_againDispenseed", @"currentTapKey" : sBlackBoardCommon, @"currentTapPage" : @(1)} Save:YES AssociatedMsgID:sClassBegin AssociatedUserID:nil expires:0 completion:nil];
            break;
        }
        case TKMiniWhiteBoardStatePrepareing:
        {
            [[TKEduSessionHandle shareInstance] sessionHandlePubMsg:sBlackBoard_new ID:sBlackBoard_new To:sTellAll Data:@{@"blackBoardState" : @"_dispenseed", @"currentTapKey" : sBlackBoardCommon, @"currentTapPage" : @(1)} Save:YES AssociatedMsgID:sClassBegin AssociatedUserID:nil expires:0 completion:nil];
            break;
        }
            
        default:
            break;
    }
}

- (void)closeMiniWhiteBoard
{
    self.hidden = YES;
    [[TKEduSessionHandle shareInstance] sessionHandleDelMsg:sBlackBoard_new ID:sBlackBoard_new To:sTellAll Data:@{} completion:nil];
    [[TKEduSessionHandle shareInstance] sessionHandleDelMsg:sMiniBlackBoard_upload ID:sMiniBlackBoard_upload To:sTellAll Data:@{} completion:nil];
}

//增加学生画布
- (BOOL)addStudent:(TKStudentSegmentObject *)student
{
    return [_segmentCotnrol addStudent:student];
}

//移除学生画布
- (void)removeStudent:(TKStudentSegmentObject *)student
{
    [_segmentCotnrol removeStudent:student];
    [_tkDrawView clearOnePageWithFileID:student.ID pageNum:1];
}

//选中学生
- (void)didSelectStudent:(TKStudentSegmentObject *)student
{
    _choosedStudent = student;
    switch (self.state) {
        case TKMiniWhiteBoardStateDispenseed:
        {
            [[TKEduSessionHandle shareInstance] sessionHandlePubMsg:sBlackBoard_new ID:sBlackBoard_new To:sTellAll Data:@{@"blackBoardState" : @"_dispenseed", @"currentTapKey" : student.ID, @"currentTapPage" : @(1)} Save:YES AssociatedMsgID:sClassBegin AssociatedUserID:nil expires:0 completion:nil];
            break;
        }
        case TKMiniWhiteBoardStateRecycle:
        {
            [[TKEduSessionHandle shareInstance] sessionHandlePubMsg:sBlackBoard_new ID:sBlackBoard_new To:sTellAll Data:@{@"blackBoardState" : @"_recycle", @"currentTapKey" : student.ID, @"currentTapPage" : @(1)} Save:YES AssociatedMsgID:sClassBegin AssociatedUserID:nil expires:0 completion:nil];
            break;
        }
        case TKMiniWhiteBoardStateAgainDispenseed:
        {
            [[TKEduSessionHandle shareInstance] sessionHandlePubMsg:sBlackBoard_new ID:sBlackBoard_new To:sTellAll Data:@{@"blackBoardState" : @"_againDispenseed", @"currentTapKey" : student.ID, @"currentTapPage" : @(1)} Save:YES AssociatedMsgID:sClassBegin AssociatedUserID:nil expires:0 completion:nil];
            break;
        }
            
        default:
            break;
    }
}

- (void)chooseStudent:(TKStudentSegmentObject *)student
{
    _choosedStudent = student;
    [_segmentCotnrol chooseStudent:student];
    //老师在分发状态下只能在自己画布上绘制，回收状态可以在所有画布上绘制
    if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Teacher) {
        if (self.state == TKMiniWhiteBoardStateAgainDispenseed || self.state == TKMiniWhiteBoardStateDispenseed) {
            if ([student.ID isEqualToString:sBlackBoardCommon]) {
                [_tkDrawView setWorkMode:TKWorkModeControllor];
            } else {
                [_tkDrawView setWorkMode:TKWorkModeViewer];
            }
        } else {
            [_tkDrawView setWorkMode:TKWorkModeControllor];
        }
    }
}

- (void)drawPen:(UIButton *)btn
{
    _penBtn.selected = YES;
    _textBtn.selected = NO;
    _eraserBtn.selected = NO;
    
    [_selectorView showType:TKSelectorShowTypeMiddle];
    [_selectorView showOnMiniWhiteBoardAboveView:btn type:TKBrushToolTypeLine];
}

- (void)drawText:(UIButton *)btn
{
    _penBtn.selected = NO;
    _textBtn.selected = YES;
    _eraserBtn.selected = NO;
    
    [_selectorView showType:TKSelectorShowTypeMiddle];
    [_selectorView showOnMiniWhiteBoardAboveView:btn type:TKBrushToolTypeText];
}

- (void)drawEraser:(UIButton *)btn
{
    _penBtn.selected = NO;
    _textBtn.selected = NO;
    _eraserBtn.selected = YES;
    
    [_selectorView showType:TKSelectorShowTypeLow];
    [_selectorView showOnMiniWhiteBoardAboveView:btn type:TKBrushToolTypeEraser];
}

- (void)upload:(UIButton *)btn
{
    _uploadBtn.selected = !_uploadBtn.selected;

    [TKEduSessionHandle shareInstance].updateImageUseType = TKUpdateImageUseType_MiniWhiteBoard;
    [[NSNotificationCenter defaultCenter] postNotificationName:sChoosePhotosUploadNotification object:sChoosePhotosUploadNotification];
    [_uploadIslandView removeFromSuperview];
    _uploadIslandView = nil;
    _uploadBtn.selected = NO;
}

- (void)displayImage:(NSString *)swfpath
{
    swfpath = swfpath.length != 0 ? swfpath : [_segmentCotnrol.swfPaths objectForKey:sBlackBoardCommon];
    if (swfpath.length == 0) {
        _imageView.image = nil;
        return;
    }
    
    NSArray *components = [swfpath componentsSeparatedByString:@"."];
    if (components.count > 1) {
        NSString *_1path  = [[[[components subarrayWithRange:NSMakeRange(0, components.count - 1)]  componentsJoinedByString:@"."] stringByAppendingString:@"-1."] stringByAppendingString:components.lastObject];
        NSString *imageURLString = [[TKWhiteBoardManager shareInstance].address stringByAppendingString:_1path];
        
        [_imageView sd_setImageWithURL:[NSURL URLWithString:[@"https://" stringByAppendingString:imageURLString]] completed:^(UIImage * _Nullable image, NSError * _Nullable error, SDImageCacheType cacheType, NSURL * _Nullable imageURL) {
            if (error || !image) {
                return ;
            }
            
            if (image.size.width / image.size.height >= _underDrawView.frame.size.width / _underDrawView.frame.size.height) {
                [_imageView mas_remakeConstraints:^(MASConstraintMaker *make) {
                    make.centerX.equalTo(_underDrawView.mas_centerX);
                    make.centerY.equalTo(_underDrawView.mas_centerY);
                    make.width.equalTo(_underDrawView.mas_width);
                    make.height.equalTo(_imageView.mas_width).multipliedBy(image.size.height / image.size.width);
                }];
            } else {
                [_imageView mas_remakeConstraints:^(MASConstraintMaker *make) {
                    make.centerX.equalTo(_underDrawView.mas_centerX);
                    make.centerY.equalTo(_underDrawView.mas_centerY);
                    make.height.equalTo(_underDrawView.mas_height);
                    make.width.equalTo(_imageView.mas_height).multipliedBy(image.size.width / image.size.height);
                }];
            }
            
        }];
    }
}
 

//选择画笔工具回调数据
- (void)brushSelectorViewDidSelectDrawType:(TKDrawType)type color:(NSString *)hexColor widthProgress:(float)progress
{
    [_tkDrawView setDrawType:type hexColor:hexColor progress:progress];
}

//发送小白板绘制数据
- (void)addSharpWithFileID:(NSString *)fileid shapeID:(NSString *)shapeID shapeData:(NSData *)shapeData
{
    [_selectorView removeFromSuperview];
    
    /******************************************************************************************************/
    //老师：回收状态下可以在任意画布上绘制，分发状态下只能在自己画布上绘制
    //学生：回收状态无法绘制，分发状态下可以在自己画布上绘制
    if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Teacher) {
        if (self.state == TKMiniWhiteBoardStateDispenseed || self.state == TKMiniWhiteBoardStateAgainDispenseed) {
            if (![fileid isEqualToString:sBlackBoardCommon]) {
                return;
            }
        }
    }
    
    if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
        if (self.state == TKMiniWhiteBoardStateDispenseed || self.state == TKMiniWhiteBoardStateAgainDispenseed) {
            if (![fileid isEqualToString:[TKEduSessionHandle shareInstance].localUser.peerID]) {
                return;
            }
        }
        if (self.state == TKMiniWhiteBoardStateRecycle) {
            return;
        }
    }
    /******************************************************************************************************/
    
    NSMutableDictionary *dic = [NSJSONSerialization JSONObjectWithData:shapeData options:NSJSONReadingMutableContainers error:nil];

    if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Teacher) {
        [dic setObject:_tkDrawView.fileid forKey:@"whiteboardID"];
        switch (self.state) {
            case TKMiniWhiteBoardStateDispenseed:

            case TKMiniWhiteBoardStateRecycle:

            case TKMiniWhiteBoardStateAgainDispenseed:
            {
                [dic setObject:@(NO) forKey:@"isBaseboard"];
                break;
            }
            case TKMiniWhiteBoardStatePrepareing:
            {
                [dic setObject:@(YES) forKey:@"isBaseboard"];
                break;
            }
            default:
                break;
        }
    }
    if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
        [dic setObject:[TKEduSessionHandle shareInstance].localUser.peerID forKey:@"whiteboardID"];
        [dic setObject:@(NO) forKey:@"isBaseboard"];
    }
    
    [dic setObject:[TKEduSessionHandle shareInstance].localUser.nickName forKey:@"nickname"];

    NSData *newData = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:nil];
    NSString *data = [[NSString alloc] initWithData:newData encoding:NSUTF8StringEncoding];
    NSString *s1 = [data stringByReplacingOccurrencesOfString:@"\n" withString:@""];

    [[TKEduSessionHandle shareInstance] sessionHandlePubMsg:sSharpsChange ID:shapeID To:sTellAll Data:s1 Save:YES AssociatedMsgID:sBlackBoard_new AssociatedUserID:nil expires:0 completion:nil];
    
    _panG.enabled = YES;
}

//每次隐藏后清理数据
- (void)clear
{
    _imageView.image = nil;
    _choosedStudent = nil;
    [_segmentCotnrol.swfPaths removeAllObjects];
    [_tkDrawView clearDataAfterClass];
    [_tkDrawView setNeedsDisplay];
    [_segmentCotnrol resetUI];
}

//画笔工具超出了self，保证超出部分也可点击
- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    //移除画笔选择工具
    if ([_selectorView pointInside:[self convertPoint:point toView:_selectorView] withEvent:event] == NO) {

        [_selectorView removeFromSuperview];
    }
        
    //触摸到就放置最前
    [self.superview bringSubviewToFront:self];
    
    _panG.enabled = YES;
    if (CGRectContainsPoint(self.bounds, point)) {
        return YES;
    }
    
    if (CGRectContainsPoint(_selectorView.frame, point)) {
        _panG.enabled = NO;
        return YES;
    }
    
    return NO;
}

- (void)handleSignal:(NSDictionary *)dictionary isDel:(BOOL)isDel
{
    if (!dictionary || dictionary.count == 0) {
        return;
    }
    
    //信令相关性
    NSString *associatedMsgID = [dictionary objectForKey:sAssociatedMsgID];
    
    //信令名
    NSString *msgName = [dictionary objectForKey:sName];
    
    //信令内容
    id dataObject = [dictionary objectForKey:@"data"];
    NSMutableDictionary *data = nil;
    if ([dataObject isKindOfClass:[NSDictionary class]]) {
        data = [NSMutableDictionary dictionaryWithDictionary:dataObject];
    }
    if ([dataObject isKindOfClass:[NSString class]]) {
        data = [NSJSONSerialization JSONObjectWithData:[(NSString *)dataObject dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingMutableContainers error:nil];
    }
    
    //大并发教室
    if ([msgName isEqualToString:@"BigRoom"]) {
        self.bigRoom = YES;
        return;
    }
    
    //小白板隐藏
    if (isDel) {
        if ([msgName isEqualToString:sBlackBoard_new]) {
            self.hidden = YES;
            [self clear];
            [_prepareData removeAllObjects];
            return;
        }
    }
    
    if ([msgName isEqualToString:sMiniBlackBoard_upload] || [msgName isEqualToString:sMiniBlackBoard_upload_Student] ) {
        NSString *swfpath = [data objectForKey:@"swfpath"];
        if (!swfpath || swfpath.length == 0) {
            return;
        }
        NSString *signalID = [dictionary objectForKey:@"id"];
        NSArray *idArray = [signalID componentsSeparatedByString:@"#talk#"];
        NSString *ID = (idArray.count == 1) ? sBlackBoardCommon : idArray.lastObject;
        [_segmentCotnrol.swfPaths setObject:swfpath forKey:ID];

        switch (self.state) {
            case TKMiniWhiteBoardStatePrepareing:
            {
                [self displayImage:swfpath];
                break;
            }
                
            case TKMiniWhiteBoardStateDispenseed:
            case  TKMiniWhiteBoardStateAgainDispenseed:
            {
                if ([TKRoomManager instance].localUser.role == TKUserType_Teacher) {
                    [self displayImage:[_segmentCotnrol.swfPaths objectForKey:_choosedStudent.ID]];
                } else if ([TKRoomManager instance].localUser.role == TKUserType_Student) {
                    [self displayImage:[_segmentCotnrol.swfPaths objectForKey:[TKRoomManager instance].localUser.peerID]];
                }
                break;
            }
            case TKMiniWhiteBoardStateRecycle:
            {
                [self displayImage:[_segmentCotnrol.swfPaths objectForKey:_choosedStudent.ID]];
                break;
            }
            default:
                break;
        }
    }
    
    if ([msgName isEqualToString:sBlackBoard_new]) {
        //小白板状态
        //_prepareing       准备
        //_dispenseed       分发
        //_recycle          收回
        //_againDispenseed  再次分发
        NSString *blackBoardState = [data objectForKey:sBlackBoardState];
        NSString *currentTapKey = [data objectForKey:sCurrentTapKey];
        
        //状态切换以及页签切换
        if ([blackBoardState isEqualToString:s_Prepareing]) {
            //修改小白板状态为TKMiniWhiteBoardStatePrepareing，此状态下老师绘制全部保存，当分发时有学生加进来则将_prepareData绘制到学生上。
            //最终结果就是老师在TKMiniWhiteBoardStatePrepareing状态下的绘制将同步到所有学生。
            [self switchStates:TKMiniWhiteBoardStatePrepareing];
            
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
                [_tkDrawView setWorkMode:TKWorkModeViewer];
                TKStudentSegmentObject *student = [[TKStudentSegmentObject alloc] init];
                student.ID = [TKEduSessionHandle shareInstance].localUser.peerID;
                student.nickName = [TKEduSessionHandle shareInstance].localUser.nickName;
                [self chooseStudent:student];
                [self displayImage:[_segmentCotnrol.swfPaths objectForKey:[TKEduSessionHandle shareInstance].localUser.peerID]];
            }
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Teacher || [TKEduSessionHandle shareInstance].localUser.role == TKUserType_Playback) {
                [self show];
                [_tkDrawView setWorkMode:TKWorkModeControllor];
                [_tkDrawView switchToFileID:sBlackBoardCommon pageID:1 refreshImmediately:YES];
                [self chooseStudent:[TKStudentSegmentObject teacher]];
                [self displayImage:[_segmentCotnrol.swfPaths objectForKey:sBlackBoardCommon]];
            }
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Patrol) {
                [self show];
                [_tkDrawView switchToFileID:sBlackBoardCommon pageID:1 refreshImmediately:YES];
                [self chooseStudent:[TKStudentSegmentObject teacher]];
                [self displayImage:[_segmentCotnrol.swfPaths objectForKey:sBlackBoardCommon]];
            }
            
        }
        if ([blackBoardState isEqualToString:s_Dispenseed]) {
            [self show];
            [self switchStates:TKMiniWhiteBoardStateDispenseed];
            //分发，学生端只显示自己画布
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
                [_tkDrawView setWorkMode:TKWorkModeControllor];
                [_tkDrawView switchToFileID:[TKEduSessionHandle shareInstance].localUser.peerID pageID:1 refreshImmediately:YES];
                [self displayImage:[_segmentCotnrol.swfPaths objectForKey:[TKEduSessionHandle shareInstance].localUser.peerID]];
            }
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Teacher || [TKEduSessionHandle shareInstance].localUser.role == TKUserType_Playback) {
                //老师切换切换画布
                [_tkDrawView setWorkMode:TKWorkModeControllor];
                [_tkDrawView switchToFileID:currentTapKey pageID:1 refreshImmediately:YES];
                if ([currentTapKey isEqualToString:sBlackBoardCommon]) {
                    [_tkDrawView setWorkMode:TKWorkModeControllor];
                } else {
                    [_tkDrawView setWorkMode:TKWorkModeViewer];
                }
                [self displayImage:[_segmentCotnrol.swfPaths objectForKey:currentTapKey]];
            }
            
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Patrol) {
                [_tkDrawView switchToFileID:currentTapKey pageID:1 refreshImmediately:YES];
                TKStudentSegmentObject *student = [[TKStudentSegmentObject alloc] init];
                student.ID = currentTapKey;
                student.currentPage = 1;
                [self chooseStudent:student];
                [self displayImage:[_segmentCotnrol.swfPaths objectForKey:currentTapKey]];
            }
            
        }
        if ([blackBoardState isEqualToString:s_AgainDispenseed]) {
            [self show];
            [self switchStates:TKMiniWhiteBoardStateAgainDispenseed];
            //再次分发，学生端只显示自己画布
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
                [_tkDrawView switchToFileID:[TKEduSessionHandle shareInstance].localUser.peerID pageID:1 refreshImmediately:YES];
                [_tkDrawView setWorkMode:TKWorkModeControllor];
                [self displayImage:[_segmentCotnrol.swfPaths objectForKey:[TKEduSessionHandle shareInstance].localUser.peerID]];
            }
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Teacher || [TKEduSessionHandle shareInstance].localUser.role == TKUserType_Playback) {
                TKStudentSegmentObject *student = [[TKStudentSegmentObject alloc] init];
                student.ID = currentTapKey;
                student.currentPage = 1;
                [_tkDrawView setWorkMode:TKWorkModeControllor];
                [self chooseStudent:student];
                [_tkDrawView switchToFileID:currentTapKey pageID:1 refreshImmediately:YES];
                if ([currentTapKey isEqualToString:sBlackBoardCommon]) {
                    [_tkDrawView setWorkMode:TKWorkModeControllor];
                } else {
                    [_tkDrawView setWorkMode:TKWorkModeViewer];
                }
                [self displayImage:[_segmentCotnrol.swfPaths objectForKey:currentTapKey]];
            }
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Patrol) {
                TKStudentSegmentObject *student = [[TKStudentSegmentObject alloc] init];
                student.ID = currentTapKey;
                student.currentPage = 1;
                [self chooseStudent:student];
                [_tkDrawView switchToFileID:currentTapKey pageID:1 refreshImmediately:YES];
                [self displayImage:[_segmentCotnrol.swfPaths objectForKey:currentTapKey]];
            }
        }
        
        if ([blackBoardState isEqualToString:s_Recycle]) {
            [self show];
            [self switchStates:TKMiniWhiteBoardStateRecycle];
            //回收，显示所有画布，根据currentTapKey选择显示的画布，blackBoardCommon代表老师
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
                TKStudentSegmentObject *student = [[TKStudentSegmentObject alloc] init];
                student.ID = currentTapKey;
                student.currentPage = 1;
                [self chooseStudent:student];
                [_tkDrawView switchToFileID:student.ID pageID:student.currentPage refreshImmediately:YES];
                [_tkDrawView setWorkMode:TKWorkModeViewer];
                [_selectorView removeFromSuperview];
                [self displayImage:[_segmentCotnrol.swfPaths objectForKey:currentTapKey]];
            }
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Teacher || [TKEduSessionHandle shareInstance].localUser.role == TKUserType_Playback) {
                TKStudentSegmentObject *student = [[TKStudentSegmentObject alloc] init];
                student.ID = currentTapKey;
                student.currentPage = 1;
                [self chooseStudent:student];
                [_tkDrawView setWorkMode:TKWorkModeControllor];
                [_tkDrawView switchToFileID:currentTapKey pageID:1 refreshImmediately:YES];
                _uploadBtn.enabled = [currentTapKey isEqualToString:sBlackBoardCommon];
                [self displayImage:[_segmentCotnrol.swfPaths objectForKey:currentTapKey]];
            }
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Patrol) {
                TKStudentSegmentObject *student = [[TKStudentSegmentObject alloc] init];
                student.ID = currentTapKey;
                student.currentPage = 1;
                [self chooseStudent:student];
                [_tkDrawView switchToFileID:currentTapKey pageID:1 refreshImmediately:YES];
                [self displayImage:[_segmentCotnrol.swfPaths objectForKey:currentTapKey]];
            }
        }
    }
    
    if ([associatedMsgID isEqualToString:sBlackBoard_new]) {
        //绘制
        if ([msgName isEqualToString:sSharpsChange]) {
            NSString *fileID = [data objectForKey:sWhiteboardID];
            
            NSNumber *isBaseboard = [data objectForKey:@"isBaseboard"];
            if (isBaseboard.boolValue) {
                //主画布数据需要同步到每个添加进来的学生
                [_prepareData addObject:data];
            }
            
            
            [_tkDrawView switchToFileID:fileID pageID:1 refreshImmediately:[fileID isEqualToString:_choosedStudent.ID]];
            [_tkDrawView addDrawData:data refreshImmediately:[fileID isEqualToString:_choosedStudent.ID]];
            
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
                //学生分发状态只显示自己画布
                if (_state == TKMiniWhiteBoardStateDispenseed || _state == TKMiniWhiteBoardStateAgainDispenseed || _state == TKMiniWhiteBoardStatePrepareing) {
                    [_tkDrawView switchToFileID:[TKEduSessionHandle shareInstance].localUser.peerID pageID:1 refreshImmediately:YES];
                }
            }
            if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Teacher || [TKEduSessionHandle shareInstance].localUser.role == TKUserType_Playback) {
                [_tkDrawView switchToFileID:self.choosedStudent.ID pageID:1 refreshImmediately:[fileID isEqualToString:self.choosedStudent.ID]];
            }
        }
        
        //新进角色
        if ([msgName isEqualToString:sUserHasNewBlackBoard]) {
            
            TKStudentSegmentObject *obj = [[TKStudentSegmentObject alloc] initWithDictionary:data];
            BOOL addRestult = [self addStudent:obj];
            
            //创建收到的新学生白板
            if (!isDel) {
                if (addRestult) {
                    [_prepareData enumerateObjectsUsingBlock:^(NSDictionary *_Nonnull data, NSUInteger idx, BOOL * _Nonnull stop) {
                        [_tkDrawView switchToFileID:obj.ID pageID:obj.currentPage refreshImmediately:NO];
                        [_tkDrawView addDrawData:data refreshImmediately:NO];
                    }];
                    
                    if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
                        if (_state == TKMiniWhiteBoardStateDispenseed || _state == TKMiniWhiteBoardStateAgainDispenseed) {
                            //分发再次分发状态都切换到自己画布
                            [_tkDrawView switchToFileID:[TKEduSessionHandle shareInstance].localUser.peerID pageID:1 refreshImmediately:YES];
                        } else {
                            [_tkDrawView switchToFileID:_choosedStudent.ID pageID:1 refreshImmediately:YES];
                        }
                    }
                    if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Teacher || [TKEduSessionHandle shareInstance].localUser.role == TKUserType_Playback) {
                        [_tkDrawView switchToFileID:sBlackBoardCommon pageID:1 refreshImmediately:YES];
                    }
                }
            } else {
                [self removeStudent:obj];
                //删除正在显示的student
                if ([obj.ID isEqualToString:_choosedStudent.ID]) {
                    if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Teacher) {
                        // 老师重新指定 当前标签
                        [self didSelectStudent:[TKStudentSegmentObject teacher]];
                        
                    } else if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Playback) {
                        
                        [_tkDrawView switchToFileID:sBlackBoardCommon pageID:1 refreshImmediately:YES];
                        [self chooseStudent:[TKStudentSegmentObject teacher]];
                        
                    } else if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
                        
                        if (_state == TKMiniWhiteBoardStateRecycle) {
                            [_tkDrawView switchToFileID:sBlackBoardCommon pageID:1 refreshImmediately:YES];
                            [self chooseStudent:[TKStudentSegmentObject teacher]];
                        }
                    }
                }
            }
        }
    }
}

- (void)show
{
    if (self.isBigRoom && [TKEduSessionHandle shareInstance].localUser.publishState == 0) {
        //大并发教室学生未上台，不显示小白板
        self.hidden = YES;
        return;
    }
    
    [self.superview bringSubviewToFront:self];
    self.hidden = NO;
    _imageView.hidden = NO;
    _uploadBtn.selected = NO;
}

- (void)setHidden:(BOOL)hidden
{
    [super setHidden:hidden];
    self.fakeView.hidden = hidden;
}
 
@end


@implementation TKMiniWhiteBoardFakeView

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    CGPoint pointOnNavBarView = [self convertPoint:point toView:self.miniWB];
    
    if (!self.miniWB.hidden && CGRectContainsPoint(self.miniWB.frame, pointOnNavBarView)) {
        return self;
    } else {
        [[UIApplication sharedApplication].keyWindow endEditing:YES];
        return nil;
    }
}

@end
