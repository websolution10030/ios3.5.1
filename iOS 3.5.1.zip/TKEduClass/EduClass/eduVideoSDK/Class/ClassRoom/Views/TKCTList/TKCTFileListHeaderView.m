//
//  TKCTFileListHeaderView.m
//  EduClass
//
//  Created by talkcloud on 2018/10/16.
//  Copyright © 2018年 talkcloud. All rights reserved.
//

#import "TKCTFileListHeaderView.h"
#import "TKEduSessionHandle.h"
#import "TKPageButton.h"

#define kMargin 10
#define btnMargin 5
#define ThemeKP(args) [@"TKDocumentListView." stringByAppendingString:args]

@interface TKCTFileListHeaderView() {
    CGFloat _typeViewWidth;
    CGFloat _btnWidth;
    CGFloat _toolHeight;
    
    UIButton  *_takePhoto;
    UIButton  *_choosePhoto;
}

@property (nonatomic, strong) UIView         *typeView;
@property (nonatomic, strong) TKPageButton   *timeSortBtn;        //时间排序
@property (nonatomic, strong) TKPageButton   *typeSortBtn;        //类型排序
@property (nonatomic, strong) TKPageButton   *nameSortBtn;        //时间排序
@property (nonatomic, strong) NSMutableArray *btnArray;           //按钮数组

@end

@implementation TKCTFileListHeaderView

- (instancetype)initWithFrame:(CGRect)frame fileType:(BOOL)type{
    if (self = [super initWithFrame:frame]) {
        _typeViewWidth = CGRectGetWidth(frame)/2.0 - kMargin*2;
        _btnWidth      = (CGRectGetWidth(frame)/2.0*0.8 - 15)/3.0;
        _toolHeight    = CGRectGetHeight(frame)/6.0*4;
        
        _nameSortBtn = ({
            TKPageButton *button = [TKPageButton buttonWithType:(UIButtonTypeCustom)];
            button.centerY = _typeView.centerY;
            button.sakura.titleColor(ThemeKP(@"listSortColor"),UIControlStateNormal);
            [button setTitle:TKMTLocalized(@"Button.nameSort") forState:(UIControlStateNormal)];
            button.sakura.image(ThemeKP(@"arrange_none"),UIControlStateNormal);
            [self addSubview:button];
            button.tag = TKSortNone;
            [button addTarget:self action:@selector(nameSortBtnClick:) forControlEvents:(UIControlEventTouchUpInside)];
            button;
        });
        
        _typeSortBtn = ({
            
            TKPageButton *button = [TKPageButton buttonWithType:(UIButtonTypeCustom)];
            button.centerY = _nameSortBtn.centerY;
            button.sakura.titleColor(ThemeKP(@"listSortColor"),UIControlStateNormal);
            [button setTitle:TKMTLocalized(@"Button.typeSort") forState:(UIControlStateNormal)];
            button.sakura.image(ThemeKP(@"arrange_none"),UIControlStateNormal);
            [button addTarget:self action:@selector(typeSortBtnClick:) forControlEvents:(UIControlEventTouchUpInside)];
            [self addSubview:button];
            button.tag = TKSortNone;
            button;
            
        });
        
        _timeSortBtn = ({
            
            TKPageButton *button = [TKPageButton buttonWithType:(UIButtonTypeCustom)];
            button.centerY = _nameSortBtn.centerY;
            button.sakura.titleColor(ThemeKP(@"listSortColor"),UIControlStateNormal);
            [button setTitle:TKMTLocalized(@"Button.timeSort") forState:(UIControlStateNormal)];
            button.sakura.image(ThemeKP(@"arrange_up"),UIControlStateNormal);
            button.sakura.image(ThemeKP(@"arrange_down"),UIControlStateNormal);
            [button addTarget:self action:@selector(timeSortBtnClick:) forControlEvents:(UIControlEventTouchUpInside)];
            [self addSubview:button];
            //            button.tag = TKSortAscending;
            button.tag = TKSortDescending;
            button;
        });
        _btnArray = [NSMutableArray arrayWithObjects:_nameSortBtn,_typeSortBtn,_timeSortBtn, nil];
        
        if (type) { //如果开启了文档分类配置项 需要不进行隐藏
            _typeView.hidden = NO;
        }else{
            _typeView.hidden = YES;
        }
        
        [self newUI];
    }
    return self;
}

- (void)newUI
{
    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.font = TKFont(18);
    titleLabel.sakura.textColor(@"TKUserListTableView.coursewareButtonYellowColor");
    titleLabel.text = TKMTLocalized(@"Title.DocumentList");
    [self addSubview:titleLabel];
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.mas_centerY);
        make.left.equalTo(self.mas_left).offset(15);
    }];
    
    _typeViewWidth = CGRectGetWidth(self.frame)/2.0 - kMargin*2;
    _btnWidth      = (CGRectGetWidth(self.frame)/2.0*0.8 - 15)/3.0;
    _toolHeight    = CGRectGetHeight(self.frame)/6.0*4;
    
    _timeSortBtn.titleLabel.font = _typeSortBtn.titleLabel.font = _nameSortBtn.titleLabel.font = TKFont(14);
    
    _timeSortBtn.sakura.titleColor(@"TKUserListTableView.coursewareButtonYellowColor",UIControlStateNormal);
    _typeSortBtn.sakura.titleColor(@"TKUserListTableView.coursewareButtonWhiteColor",UIControlStateNormal);
    _nameSortBtn.sakura.titleColor(@"TKUserListTableView.coursewareButtonWhiteColor",UIControlStateNormal);
        
    _choosePhoto = [UIButton buttonWithType:UIButtonTypeCustom];
    [_choosePhoto addTarget:self action:@selector(choosePhoto) forControlEvents:UIControlEventTouchUpInside];
    _choosePhoto.sakura.backgroundImage(ThemeKP(@"uploadFromLibrary"), UIControlStateNormal);
    [self addSubview:_choosePhoto];
    [_choosePhoto mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(38, 38)]);
        make.centerY.equalTo(self.mas_centerY);
        make.right.equalTo(self.mas_right).offset(-10);
    }];

    _takePhoto = [UIButton buttonWithType:UIButtonTypeCustom];
    [_takePhoto addTarget:self action:@selector(takePhoto) forControlEvents:UIControlEventTouchUpInside];
    _takePhoto.sakura.backgroundImage(ThemeKP(@"uploadFromCamera"), UIControlStateNormal);
    [self addSubview:_takePhoto];
    [_takePhoto mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(38, 38)]);
        make.centerY.equalTo(self.mas_centerY);
        make.right.equalTo(_choosePhoto.mas_left).offset(-20);
    }];
    
    [_nameSortBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(_btnWidth, _btnWidth)]);
        make.centerY.equalTo(self.mas_centerY);
        make.right.equalTo(_takePhoto.mas_left).offset(-10);
    }];
    
    [_typeSortBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(_btnWidth, _btnWidth)]);
        make.centerY.equalTo(self.mas_centerY);
        make.right.equalTo(_nameSortBtn.mas_left).offset(-10);
    }];
    
    [_timeSortBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(_btnWidth, _btnWidth)]);
        make.centerY.equalTo(self.mas_centerY);
        make.right.equalTo(_typeSortBtn.mas_left).offset(-10);
    }];
    
    if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Patrol ) {
        _takePhoto.hidden = YES;
        _choosePhoto.hidden = YES;
    }
}

- (void)takePhoto
{
    if (self.takePhotoActionBlock) {
        self.takePhotoActionBlock();
    }
}

- (void)choosePhoto
{
    if (self.choosePhotoActionblock) {
        self.choosePhotoActionblock();
    }
}

- (void)hideUploadButton:(BOOL)hide
{
    if ([TKEduSessionHandle shareInstance].localUser.role == TKUserType_Patrol || [TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
        _choosePhoto.hidden = YES;
        _takePhoto.hidden = YES;
    } else {
        _choosePhoto.hidden = hide;
        _takePhoto.hidden = hide;
    }
}

- (void)setTheHalfAngle:(UIButton *)button rectCorner:(UIRectCorner)rectCorner cornerRadii:(CGFloat)radii{
    
    button.titleLabel.font = IS_PAD ? TKFont(15) : [UIFont systemFontOfSize:button.height/3.0*2.0];
    UIBezierPath *maskPath=[UIBezierPath bezierPathWithRoundedRect:button.bounds byRoundingCorners:rectCorner cornerRadii:CGSizeMake(radii, radii)];
    CAShapeLayer *maskLayer=[[CAShapeLayer alloc]init];
    maskLayer.frame=button.bounds;
    maskLayer.path=maskPath.CGPath;
    button.layer.mask=maskLayer;
    
}

//            arrange_down
//            arrange_none
//            arrange_up
- (void)refreshUI{
    for (UIButton *button in _btnArray) {
        switch (button.tag) {
            case TKSortAscending:
                button.sakura.image(ThemeKP(@"arrange_up"),UIControlStateNormal);
                break;
            case TKSortDescending:
                
                button.sakura.image(ThemeKP(@"arrange_down"),UIControlStateNormal);
                break;
            case TKSortNone:
                
                button.sakura.image(ThemeKP(@"arrange_none"),UIControlStateNormal);
                break;
            default:
                break;
        }
    }
}
- (void)nameSortBtnClick:(UIButton *)sender{
    
    for (UIButton *btn in _btnArray) {
        btn.sakura.titleColor(@"TKUserListTableView.coursewareButtonWhiteColor",UIControlStateNormal);
    }
    sender.sakura.titleColor(@"TKUserListTableView.coursewareButtonYellowColor",UIControlStateNormal);
    
    switch (sender.tag) {
        case TKSortAscending:
        {
            sender.tag = TKSortDescending;
            _typeSortBtn.tag = TKSortNone;
            _timeSortBtn.tag = TKSortNone;
            
            if (self.delegate && [self.delegate respondsToSelector:@selector(nameSort:)]) {
                [self.delegate nameSort:TKSortDescending];
                
            }
        }
            break;
        case TKSortDescending:
        case TKSortNone:
        {
            sender.tag = TKSortAscending;
            _typeSortBtn.tag = TKSortNone;
            _timeSortBtn.tag = TKSortNone;
            
            if (self.delegate && [self.delegate respondsToSelector:@selector(nameSort:)]) {
                [self.delegate nameSort:TKSortAscending];
                
            }
        }
            break;
            
        default:
            break;
    }
    [self refreshUI];
    
}

- (void)typeSortBtnClick:(UIButton *)sender{
    for (UIButton *btn in _btnArray) {
        btn.sakura.titleColor(@"TKUserListTableView.coursewareButtonWhiteColor",UIControlStateNormal);
    }
    sender.sakura.titleColor(@"TKUserListTableView.coursewareButtonYellowColor",UIControlStateNormal);
    switch (sender.tag) {
        case TKSortAscending:
        {
            sender.tag = TKSortDescending;
            _nameSortBtn.tag = TKSortNone;
            _timeSortBtn.tag = TKSortNone;
            
            if (self.delegate && [self.delegate respondsToSelector:@selector(typeSort:)]) {
                [self.delegate typeSort:TKSortDescending];
                
            }
        }
            break;
        case TKSortDescending:
        case TKSortNone:
        {
            
            sender.tag = TKSortAscending;
            _nameSortBtn.tag = TKSortNone;
            _timeSortBtn.tag = TKSortNone;
            if (self.delegate && [self.delegate respondsToSelector:@selector(typeSort:)]) {
                [self.delegate typeSort:TKSortAscending];
                
            }
        }
            break;
            
        default:
            break;
    }
    
    [self refreshUI];
}
- (void)timeSortBtnClick:(UIButton *)sender{
    for (UIButton *btn in _btnArray) {
        btn.sakura.titleColor(@"TKUserListTableView.coursewareButtonWhiteColor",UIControlStateNormal);
    }
    sender.sakura.titleColor(@"TKUserListTableView.coursewareButtonYellowColor",UIControlStateNormal);
    switch (sender.tag) {
        case TKSortAscending:
        {
            sender.tag = TKSortDescending;
            _typeSortBtn.tag = TKSortNone;
            _nameSortBtn.tag = TKSortNone;
            
            if (self.delegate && [self.delegate respondsToSelector:@selector(timeSort:)]) {
                [self.delegate timeSort:TKSortDescending];
                
            }
        }
            break;
        case TKSortDescending:
        case TKSortNone:
        {
            sender.tag = TKSortAscending;
            _typeSortBtn.tag = TKSortNone;
            _nameSortBtn.tag = TKSortNone;
            if (self.delegate && [self.delegate respondsToSelector:@selector(timeSort:)]) {
                [self.delegate timeSort:TKSortAscending];
                
            }
        }
            break;
            
        default:
            break;
    }
    
    [self refreshUI];
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

@end

