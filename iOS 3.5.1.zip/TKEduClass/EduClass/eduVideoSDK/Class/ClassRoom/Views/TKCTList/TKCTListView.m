//
//  TKCTListView.m
//  EduClass
//
//  Created by talkcloud on 2018/10/15.
//  Copyright © 2018年 talkcloud. All rights reserved.
//

#import "TKCTListView.h"
#import <QuartzCore/QuartzCore.h>
#import "TKCTDocumentListView.h"
#import "TKEduSessionHandle.h"
#import "TKMediaDocModel.h"

#define ThemeKP(args) [@"TKListView." stringByAppendingString:args]

@interface TKCTListView ()<TKCTDocumentListDelegate>

@property (nonatomic, strong) TKCTDocumentListView *documentListView;//课件库

@end

@implementation TKCTListView

- (id)initWithFrame:(CGRect)frame andTitle:(NSString *)title from:(NSString *)from
{
    if (self = [super initWithFrame:frame]) {
        
        //标题空间
        self.titleText = TKMTLocalized(@"Title.DocumentList");
                
        self.contentImageView.frame = CGRectMake(0, self.titleH, self.backImageView.width, self.backImageView.height - self.titleH - 3);
        self.contentImageView.sakura.image(@"TKBaseView.base_bg_corner_4");
        
        // 文件库
        _documentListView = [[TKCTDocumentListView alloc]initWithFrame:CGRectMake(10, 0, CGRectGetWidth(self.contentImageView.frame), CGRectGetHeight(self.frame))];
        [self addSubview:_documentListView];
        _documentListView.documentDelegate = self;
        
        //默认状态文档列表显示
        [_documentListView show:TKFileListTypeDocument isClassBegin:[TKEduSessionHandle shareInstance].isClassBegin];
        
        [self newUI];
    }
    return self;
}

- (void)newUI
{
    self.userInteractionEnabled = YES;
    [self.backImageView removeFromSuperview];
    [self.contentImageView removeFromSuperview];
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
    backView.userInteractionEnabled = YES;
    backView.backgroundColor = UIColor.clearColor;
    backView.sakura.backgroundColor(ThemeKP(@"courseware_bg_Color"));
    backView.sakura.alpha(ThemeKP(@"courseware_bg_alpha"));
    backView.backgroundColor = [backView.backgroundColor colorWithAlphaComponent:backView.alpha];
    backView.alpha = 1;
    [self addSubview:backView];
    [self sendSubviewToBack:backView];
    
    CGFloat leftSpace = self.backImageView.width / 7;
    CGFloat courseW = leftSpace - 6;
    
    UIView *btnBackView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, courseW + 12, self.height)];
    btnBackView.sakura.backgroundColor(ThemeKP(@"courseware_selectView_bg_Color"));
    btnBackView.sakura.alpha(ThemeKP(@"courseware_selectView_bg_alpha"));
    [backView addSubview:btnBackView];
    _documentListView.frame = CGRectMake(0, 0, self.width, self.height);
}

- (void)touchOutSide{
    [self dismissAlert];
}

- (void)watchFile{
    [self dismissAlert];
}

- (void)deleteFile {
    [self dismissAlert];
}

- (void)show:(UIView *)view
{
    [view addSubview:self];
    CGRect rect = self.frame;
    self.frame = CGRectMake(ScreenW, rect.origin.y, rect.size.width, rect.size.height);
    [view addSubview:self];
    [view bringSubviewToFront:self];
    
    [UIView animateWithDuration:0.3f animations:^{
        self.frame = CGRectMake(ScreenW - rect.size.width, rect.origin.y, rect.size.width, rect.size.height);
    }];
}

- (void)hidden{
    
    [self dismissAlert];
}

- (void)dismissAlert
{
    [UIView animateWithDuration:0.3f
                     animations:^{
                         
                         CGRect rect = self.frame;
                         self.frame = CGRectMake(ScreenW, rect.origin.y, rect.size.width, rect.size.height);
                         
                     }
                     completion:^(BOOL finished){
                         
                         [self removeFromSuperview];
                         if (self.dismissBlock) {
                             self.dismissBlock();
                         }
                     }];
    
    
}
- (UIViewController *)appRootViewController
{
    UIViewController *appRootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
    UIViewController *topVC = appRootVC;
    while (topVC.presentedViewController) {
        topVC = topVC.presentedViewController;
    }
    return topVC;
}
- (void)removeFromSuperview
{
    [super removeFromSuperview];
}
@end


