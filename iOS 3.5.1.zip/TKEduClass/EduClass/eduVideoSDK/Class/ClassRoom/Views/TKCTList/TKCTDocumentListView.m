//
//  TKCTDocumentListView.m
//  EduClass
//
//  Created by talkcloud on 2018/10/16.
//  Copyright © 2018年 talkcloud. All rights reserved.
//

#import "TKCTDocumentListView.h"
#import "TKCTFileListTableViewCell.h"
#import "TKMediaDocModel.h"
#import "TKDocmentDocModel.h"
#import "UIView+TKExtension.h"
#import "TKCTFileListHeaderView.h"
#import "TKManyViewController+Media.h"
#import "TKHUD.h"

#define ThemeKP(args) [@"TKDocumentListView." stringByAppendingString:args]
#define kMargin 10
@interface TKCTDocumentListView ()<listCTProtocol,TKCTFileListHeaderViewDelegate>
{
    CGFloat _toolHeight;//工具条高度
    CGFloat _bottomHeight;//底部按钮高度
}

@property (nonatomic,assign)TKFileListType  iFileListType;
@property (nonatomic,strong)NSMutableArray <TKDocmentDocModel *>*iFileMutableArray;
@property (nonatomic,strong)NSMutableArray *iClassFileMutableArray;//课堂文件
@property (nonatomic,strong)NSMutableArray *iSystemFileMutableArray;//公共文件
@property (nonatomic,retain)UITableView    *iFileTableView;//展示tableview
@property (nonatomic,assign)BOOL  isClassBegin;//课堂是否开始
@property (nonatomic,strong)UIButton*  iCurrrentButton;
@property (nonatomic,strong)UIButton*  iPreButton;
@property (nonatomic, strong) TKCTFileListHeaderView *fileListHeaderView;//文档工具栏视图
@property (nonatomic, assign) BOOL filecategory;//文档类型 true 分类   false 未分类
@property (nonatomic, assign) TKFileType switchfileType;

@end

@implementation TKCTDocumentListView
-(instancetype)initWithFrame:(CGRect)frame{
    
    if (self = [super initWithFrame:frame]) {
        self.hidden = YES;
        _toolHeight = IS_PAD?CGRectGetHeight(frame)/10.0:60;
        _bottomHeight = IS_PAD ? 50:40;
        
        _filecategory = [TKEduClassRoom shareInstance].roomJson.configuration.documentCategoryFlag;
        _switchfileType = TKClassFileType;
        
        [self loadTableView:frame];
    }
    return self;
}

-(void)loadTableView:(CGRect)frame{
    
    //文档、媒体头部视图
    _fileListHeaderView = [[TKCTFileListHeaderView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(frame), _toolHeight) fileType:_filecategory];
    [self addSubview:_fileListHeaderView];
    _fileListHeaderView.hidden = YES;
    _fileListHeaderView.delegate = self;
    
    _iFileTableView = [[UITableView alloc]initWithFrame:CGRectMake(0, _toolHeight, CGRectGetWidth(frame), CGRectGetHeight(frame)-_toolHeight) style:UITableViewStylePlain];
    _iFileTableView.backgroundColor = [UIColor clearColor];
    _iFileTableView.separatorColor  = [UIColor clearColor];
    _iFileTableView.showsHorizontalScrollIndicator = NO;
    _iFileTableView.delegate   = self;
    _iFileTableView.dataSource = self;
    _isClassBegin = NO;
    _iFileTableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    
    [_iFileTableView registerClass:[TKCTFileListTableViewCell class] forCellReuseIdentifier:@"TKCTFileListTableViewCellID"];
    [self addSubview:_iFileTableView];
    
    _fileListHeaderView.takePhotoActionBlock = ^{
        [TKEduSessionHandle shareInstance].updateImageUseType = TKUpdateImageUseType_Document;
        [[NSNotificationCenter defaultCenter] postNotificationName:sTakePhotosUploadNotification object:sTakePhotosUploadNotification];
    };
    _fileListHeaderView.choosePhotoActionblock = ^{
        [TKEduSessionHandle shareInstance].updateImageUseType = TKUpdateImageUseType_Document;
        [[NSNotificationCenter defaultCenter] postNotificationName:sChoosePhotosUploadNotification object:sChoosePhotosUploadNotification];
    };
}

- (void)reloadData {
    
    [self refreshDataisClassBegin:_isClassBegin];
}

#pragma mark tableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _iFileMutableArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *tCell;
    NSString *tString;
    
    
    if ([[TKEduSessionHandle shareInstance].docmentArray containsObject:[_iFileMutableArray objectAtIndex:indexPath.row]]) {
        _iFileListType = TKFileListTypeDocument;
    } else {
        _iFileListType = TKFileListTypeAudioAndVideo;
    }
    
    switch (_iFileListType) {
        case TKFileListTypeAudioAndVideo:
        {
            TKCTFileListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TKCTFileListTableViewCellID" forIndexPath:indexPath];
            cell.delegate = self;
            cell.iIndexPath = indexPath;
            tCell = cell;
            
            //@"影音列表"
            tString = [NSString stringWithFormat:@"%@(%@)", TKMTLocalized(@"Title.MediaList"),@([[TKEduSessionHandle shareInstance].mediaArray count])];
            
            TKMediaDocModel *tMediaDocModel = [_iFileMutableArray objectAtIndex:indexPath.row];
            
            [cell configaration:tMediaDocModel withFileListType:TKFileListTypeAudioAndVideo isClassBegin:_isClassBegin];
            if (_switchfileType == TKSystemFileType || [TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
                cell.deleteBtn.hidden = YES;
            }
        }
            break;
        case TKFileListTypeDocument:
        {
            
            TKCTFileListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TKCTFileListTableViewCellID" forIndexPath:indexPath];
            cell.delegate = self;
            cell.iIndexPath = indexPath;
            tCell = cell;
            //文档列表
            tString = [NSString stringWithFormat:@"%@(%@)", TKMTLocalized(@"Title.DocumentList"),@([[TKEduSessionHandle shareInstance].docmentArray count])];
            
            TKDocmentDocModel *tMediaDocModel = [_iFileMutableArray objectAtIndex:indexPath.row];
            [cell configaration:tMediaDocModel withFileListType:TKFileListTypeDocument isClassBegin:_isClassBegin];
            if (_switchfileType == TKSystemFileType || [TKEduSessionHandle shareInstance].localUser.role == TKUserType_Student) {
                cell.deleteBtn.hidden = YES;
            }
            
        }
            break;
        default:
            break;
    }
    
    tCell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return tCell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([TKEduClassRoom shareInstance].roomJson.roomrole == TKUserType_Patrol) {
        return;
    }
    
    TKCTFileListTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    UIButton *aButton = cell.watchBtn;
    [self watchFile:aButton aIndexPath:indexPath withModel:_iFileMutableArray[indexPath.row]];
}

-(void)show:(TKFileListType)aFileListType isClassBegin:(BOOL)isClassBegin{
    
    self.hidden = NO;
    
    [self refreshDataisClassBegin:isClassBegin];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(updateData) name:sDocListViewNotification object:nil];
}

-(void)hide{
    
    self.hidden = YES;
    self.fileListHeaderView.hidden = YES;
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)updateData{
    
//    if (_iFileMutableArray.count == 0) {
        _iFileMutableArray = [NSMutableArray arrayWithArray:[[TKEduSessionHandle shareInstance].docmentArray arrayByAddingObjectsFromArray:[TKEduSessionHandle shareInstance].mediaArray]];
//    }
    
    [_iFileTableView reloadData];
}

-(void)refreshDataisClassBegin:(BOOL)isClassBegin{
        _isClassBegin = isClassBegin;
    self.fileListHeaderView.hidden = NO;
    [_fileListHeaderView hideUploadButton:NO];
    if (_iFileMutableArray.count == 0) {
        _iFileMutableArray = [NSMutableArray arrayWithArray:[[TKEduSessionHandle shareInstance].docmentArray arrayByAddingObjectsFromArray:[TKEduSessionHandle shareInstance].mediaArray]];
    }
    [_iFileTableView reloadData];
}



#pragma mark - 课件切换
- (void)watchFile:(UIButton *)aButton aIndexPath:(NSIndexPath *)aIndexPath withModel:(id)model
{
    
    if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(watchFile)]) {
        
        
    }
    if( [TKEduSessionHandle shareInstance].localUser.role == TKUserType_Patrol){
        return;
    }
    if ([[TKEduSessionHandle shareInstance].docmentArray containsObject:[_iFileMutableArray objectAtIndex:aIndexPath.row]]) {
        _iFileListType = TKFileListTypeDocument;
    } else {
        _iFileListType = TKFileListTypeAudioAndVideo;
    }
    
    NSString *tString;
    switch (_iFileListType) {
        case TKFileListTypeAudioAndVideo:
        {
            if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(watchFile)]) {
                //播放音视频收起 课件库
                [self.documentDelegate watchFile];
            }
            
            TKMediaDocModel *tMediaDocModel =  model;//[tmpArray objectAtIndex:aIndexPath.row];
            if ([[NSString stringWithFormat:@"%@",tMediaDocModel.fileid] isEqualToString:[NSString stringWithFormat:@"%@",[TKEduSessionHandle shareInstance].iCurrentMediaDocModel.fileid]]) {
                [[TKEduSessionHandle shareInstance] sessionHandleMediaPause:[TKEduSessionHandle shareInstance].iIsPlaying];
                [TKEduSessionHandle shareInstance].iIsPlaying = ![TKEduSessionHandle shareInstance].iIsPlaying;
                aButton.selected = [TKEduSessionHandle shareInstance].iIsPlaying;
                return;
            }
            aButton.selected = YES;
            
            // 正在播放时，需先停止再播放新媒体
            if ([TKEduSessionHandle shareInstance].isPlayMedia) {
                
                [TKEduSessionHandle shareInstance].isPlayMedia = NO;
                [[TKEduSessionHandle shareInstance] sessionHandleUnpublishMedia:nil];
            }
            
            NSString *tNewURLString2 = [TKUtil absolutefileUrl:tMediaDocModel.swfpath
                                                         webIp:sHost
                                                       webPort:sPort];
            [TKEduSessionHandle shareInstance].iPreMediaDocModel = [TKEduSessionHandle shareInstance].iCurrentMediaDocModel;
            [TKEduSessionHandle shareInstance].iCurrentMediaDocModel = tMediaDocModel;
            BOOL tIsVideo = [TKUtil isVideo:tMediaDocModel.filetype];
            NSString * toID = [TKEduSessionHandle shareInstance].isClassBegin ? sTellAll:  [TKEduSessionHandle shareInstance].localUser.peerID;
            [[TKEduSessionHandle shareInstance] sessionHandlePublishMedia:tNewURLString2
                                                                 hasVideo:tIsVideo
                                                                   fileid:[NSString stringWithFormat:@"%@",tMediaDocModel.fileid]
                                                                 filename:tMediaDocModel.filename
                                                                     toID:toID
                                                                    block:^(NSError *error) {
                
            }];
            if ([TKEduSessionHandle shareInstance].iIsPlaying != YES) {
                [TKEduSessionHandle shareInstance].iIsPlaying = YES;
            }
            
        }
            break;
        case TKFileListTypeDocument:
        {
            //文档列表
            tString = [NSString stringWithFormat:@"%@(%@)", TKMTLocalized(@"Title.DocumentList"),@([[TKEduSessionHandle shareInstance].docmentArray count])];
            
            
            
            [aButton setSelected:YES];
            
            TKDocmentDocModel *tDocmentDocModel = model;//[tmpArray objectAtIndex:aIndexPath.row];
            
            if ([TKEduSessionHandle shareInstance].isClassBegin) {
                [[TKEduSessionHandle shareInstance] publishtDocMentDocModel:tDocmentDocModel To:sTellAllExpectSender aTellLocal:YES];
                
            }else{
                
                [[TKEduSessionHandle shareInstance].whiteBoardManager showDocumentWithFile:(TKFileModel *)tDocmentDocModel isPubMsg:NO];
                
                [TKEduSessionHandle shareInstance].iCurrentDocmentModel = tDocmentDocModel;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:sShowPageBeforeClass object:nil];
            }
            
            
            _iCurrrentButton = aButton;
            if (_iPreButton) {
                [_iPreButton setSelected:NO];
            }
            
            _iPreButton = _iCurrrentButton;
        }
            break;
            
        default:
            break;
    }
    
    [self reloadData];
}
//涂鸦，删除文件，影音
- (void)deleteFile:(UIButton *)aButton aIndexPath:(NSIndexPath *)aIndexPath withModel:(id)model
{
    if ([TKEduClassRoom shareInstance].roomJson.roomrole == TKUserType_Patrol) {
        return;
    }
    TKAlertView *alert = [[TKAlertView alloc]initForWarningWithTitle:TKMTLocalized(@"Prompt.prompt") contentText:TKMTLocalized(@"Prompt.delClassFile") leftTitle:TKMTLocalized(@"Prompt.Cancel") rightTitle:TKMTLocalized(@"Prompt.OK")];
    [alert show];
    alert.rightBlock = ^{
        
        if (self.documentDelegate && [self.documentDelegate respondsToSelector:@selector(deleteFile)]) {
            [self.documentDelegate deleteFile];
        }
        
        if( [TKEduSessionHandle shareInstance].localUser.role == TKUserType_Patrol){
            return;
        }
        
        if ([[TKEduSessionHandle shareInstance].docmentArray containsObject:[_iFileMutableArray objectAtIndex:aIndexPath.row]]) {
            _iFileListType = TKFileListTypeDocument;
        } else {
            _iFileListType = TKFileListTypeAudioAndVideo;
        }
        
        NSString *tString;
        switch (_iFileListType) {
            case TKFileListTypeAudioAndVideo:
            {
                // 按钮点击后需要等待网络回调后才可用
                aButton.enabled = NO;
                
                //@"影音列表"
                tString = [NSString stringWithFormat:@"%@(%@)", TKMTLocalized(@"Title.MediaList"),@([_iFileMutableArray count])];
                
                TKMediaDocModel *tMediaDocModel = (TKMediaDocModel *)model;
                
                [TKEduNetManager delRoomFile:[TKEduClassRoom shareInstance].roomJson.roomid
                                       docid:[NSString stringWithFormat:@"%@",tMediaDocModel.fileid]
                                     isMedia:false
                                       aHost:sHost
                                       aPort:sPort
                                aDelComplete:^int(id  _Nullable response) {
                    
                    
                    BOOL isCurrntDM = [[TKEduSessionHandle shareInstance] isEqualFileId:tMediaDocModel aSecondModel:[TKEduSessionHandle shareInstance].iCurrentMediaDocModel];
                    if (isCurrntDM) {
                        [[TKEduSessionHandle shareInstance]sessionHandleUnpublishMedia:nil];
                    }
                    
                    [[TKEduSessionHandle shareInstance] deleteaMediaDocModel:tMediaDocModel To:sTellAllExpectSender];
                    [[TKEduSessionHandle shareInstance] delMediaArray:tMediaDocModel];
                    _iFileMutableArray = [[[TKEduSessionHandle shareInstance] mediaArray]mutableCopy];
                    
                    // 网络回调完成，按钮可用
                    aButton.enabled = YES;
                    [_iFileTableView reloadData];
                    return 1;
                    
                }aNetError:^int(id  _Nullable response) {
                    
                    // 网络回调完成，按钮可用
                    aButton.enabled = YES;
                    return -1;
                    
                }];
                
            }
                break;
            case TKFileListTypeDocument:
            {
                // 按钮点击后需要等待网络回调后才可用
                aButton.enabled = NO;
                
                //@"文档列表"
                tString = [NSString stringWithFormat:@"%@(%@)", TKMTLocalized(@"Title.DocumentList"),@([_iFileMutableArray count])];
                
                
                //            TKDocmentDocModel *tDocmentDocModel = [_iFileMutableArray objectAtIndex:aIndexPath.row];
                TKDocmentDocModel *tDocmentDocModel = (TKDocmentDocModel *)model;
                
                [TKEduNetManager delRoomFile:[TKEduClassRoom shareInstance].roomJson.roomid
                                       docid:[NSString stringWithFormat:@"%@",tDocmentDocModel.fileid]
                                     isMedia:false
                                       aHost:sHost
                                       aPort:sPort
                                aDelComplete:^int(id  _Nullable response) {
                    
                    [[TKEduSessionHandle shareInstance] deleteDocMentDocModel:tDocmentDocModel To:sTellAll];
                    
                    // 网络回调完成，按钮可用
                    aButton.enabled = YES;
                    [_iFileTableView reloadData];
                    return 1;
                }aNetError:^int(id  _Nullable response) {
                    // 网络回调完成，按钮可用
                    aButton.enabled = YES;
                    return -1;
                }];
            }
                break;
                
            default:
                break;
        }
    };
}

//名称排序
- (void)nameSort:(TKSortFileType)type{
    
    TKDocmentDocModel *whiteBoard;
    whiteBoard = [TKEduSessionHandle shareInstance].whiteBoard;
    if (whiteBoard) {
        [_iFileMutableArray removeObjectAtIndex:0];
    }
    [TKSortTool sortByNameWithArray:_iFileMutableArray fileListType:_iFileListType sortWay:type sectionBlock:^(id sectionContent) {
        
    } sortTheValueOfBlock:^(id returnValue) {
        _iFileMutableArray = [NSMutableArray arrayWithArray:(NSArray *)returnValue];
        if (whiteBoard) {
            
            [_iFileMutableArray insertObject:whiteBoard atIndex:0];
            
        }
    }];
    
    [self refreshDataisClassBegin:_isClassBegin];
}
//类型排序
- (void)typeSort:(TKSortFileType)type{
    
    TKDocmentDocModel *whiteBoard;
    whiteBoard = [TKEduSessionHandle shareInstance].whiteBoard;
    if (whiteBoard) {
        [_iFileMutableArray removeObjectAtIndex:0];
    }
    
    [TKSortTool sortByTypeWithArray:_iFileMutableArray fileListType:_iFileListType sortWay:type sectionBlock:^(id sectionContent) {
        
    } sortTheValueOfBlock:^(id returnValue) {
        _iFileMutableArray = [NSMutableArray arrayWithArray:(NSArray *)returnValue];
        if (whiteBoard) {
            
            [_iFileMutableArray insertObject:whiteBoard atIndex:0];
        }
    }];
    
    
    [self refreshDataisClassBegin:_isClassBegin];
}
//时间排序
- (void)timeSort:(TKSortFileType)type{
    
    TKDocmentDocModel *whiteBoard;
    whiteBoard = [TKEduSessionHandle shareInstance].whiteBoard;
    if (whiteBoard) {
        [_iFileMutableArray removeObjectAtIndex:0];
    }
    [TKSortTool sortByTimeWithArray:_iFileMutableArray fileListType:_iFileListType sortWay:type sectionBlock:^(id sectionContent) {
        
    } sortTheValueOfBlock:^(id returnValue) {
        _iFileMutableArray = [NSMutableArray arrayWithArray:(NSArray *)returnValue];
        if (whiteBoard) {
            
            [_iFileMutableArray insertObject:whiteBoard atIndex:0];
            
        }
    }];
    
    [self refreshDataisClassBegin:_isClassBegin];
}

-(void)dealloc{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end

