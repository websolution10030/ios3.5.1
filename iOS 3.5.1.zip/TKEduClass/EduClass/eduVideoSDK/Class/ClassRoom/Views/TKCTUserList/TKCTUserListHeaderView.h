//
//  TKCTUserListHeaderView.h
//  EduClass
//
//  Created by talkcloud on 2018/10/15.
//  Copyright © 2018年 talkcloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TKCTUserListHeaderView : UIView

- (void)setTitleHeight:(CGFloat)height;

@end
