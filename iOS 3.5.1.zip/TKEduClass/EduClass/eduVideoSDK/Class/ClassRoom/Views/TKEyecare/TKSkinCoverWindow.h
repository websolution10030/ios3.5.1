//
//  TKSkinCoverWindow.h
//  shade
//
//  Created by Evan on 2019/12/18.
//  Copyright © 2019 Evan. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TKSkinCoverWindow : UIWindow

@end

NS_ASSUME_NONNULL_END
