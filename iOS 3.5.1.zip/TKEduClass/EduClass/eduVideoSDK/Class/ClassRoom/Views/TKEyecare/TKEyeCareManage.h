//
//  TKEyeCareManage.h
//  shade
//
//  Created by Evan on 2019/12/18.
//  Copyright © 2019 Evan. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TKEyeCareManage : NSObject

/**
 * 单例创建方法
 * @return 单例对象
 */
+ (instancetype)sharedUtil;

/**
 * 护眼模式是否已经打开
 * @return 是否已经打开
 */
- (BOOL)queryEyeCareModeStatus;


/**
 * 切换护眼模式
 * @param on 是否打开 //直接使用keyWindow (正在使用的)

 */
- (void)switchEyeCareMode:(BOOL)on;

/**
* 切换护眼模式
* @param on 是否打开
*/
- (void)switchEyeCareMode2:(BOOL)on;

@end

NS_ASSUME_NONNULL_END
