//
//  TKChatToolView.m
//  EduClass
//
//  Created by lyy on 2018/4/27.
//  Copyright © 2018年 talkcloud. All rights reserved.
//

#import "TKChatToolView.h"
#import "TKEmotionTextView.h"
#import "TKEmotionKeyboard.h"
#import "TKEmojiHeader.h"
#import "TKChatQuickreplyView.h"

#define ThemeKP(args) [@"ClassRoom.TKChatViews." stringByAppendingString:args]
#define emotionWidth 30 // 表情按钮 宽度

@interface TKChatToolView()<UITextViewDelegate,TKChatQuickreplyDelegate>

@property (nonatomic, strong) UIImageView *backImageView;//背景图
@property (nonatomic, strong) TKEmotionKeyboard *kerboard; //自定义表情键盘
@property (nonatomic, strong) UIButton *sendButton;//发送按钮
@property (nonatomic, strong) UIButton *picButton;//图片选择按钮
@property (nonatomic, strong) UIButton *replyButton;//快捷回复
@property (nonatomic, strong) UIView   *vLineView;//按钮竖界

@property (nonatomic, strong) TKChatQuickreplyView * quickreplyView;

@property (nonatomic, assign) NSInteger lineCount;
@end

@implementation TKChatToolView
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {

        [self loadNotificatio];

        _inputField =({
            
            TKEmotionTextView *tInputField =  [[TKEmotionTextView alloc] init];
            tInputField.sakura.backgroundColor(ThemeKP(@"chatToolBackgroundColor"));
            tInputField.sakura.textColor(ThemeKP(@"chatToolTextColor"));
            tInputField.placehoder = TKMTLocalized(@"Say.say");
            tInputField.font = [UIFont systemFontOfSize:15];
            tInputField.delegate = self;
            //        tInputField.maxNumberOfLines = 5;
            tInputField.returnKeyType = UIReturnKeySend;
            tInputField.keyboardDismissMode = UIScrollViewKeyboardDismissModeNone;
            
            tInputField.layer.masksToBounds = YES;
            tInputField.layer.cornerRadius = 5;
            tInputField.layer.borderColor = [TKTheme cgColorWithPath:ThemeKP(@"chatToolTextFBorderColor")];
            tInputField.layer.borderWidth = [TKTheme floatWithPath:ThemeKP(@"chatToolTextFBorderWidth")];
            tInputField;
            
        });
        self.inputField.layer.borderColor = UIColor.clearColor.CGColor;
        [self addSubview:_inputField];
        
        _sendButton =({
            UIButton *button = [UIButton buttonWithType:(UIButtonTypeCustom)];
            
            [button setTitle:TKMTLocalized(@"Button.send") forState:(UIControlStateNormal)];
            button.sakura.titleColor(ThemeKP(@"chatToolBackgroundColor"),UIControlStateNormal);
            button.sakura.backgroundImage(ThemeKP(@"button_send_default"),UIControlStateNormal);
            [button addTarget:self action:@selector(sendButtonClick:) forControlEvents:(UIControlEventTouchUpInside)];
            
            button;
        });
        
        [self addSubview:_sendButton];
        
        if ([TKEduClassRoom shareInstance].roomJson.islanguagepack) {
            
            _replyButton = ({
                UIButton *button = [UIButton  buttonWithType:(UIButtonTypeCustom)];
                
                [button setImage:[UIImage imageNamed:@"tk_icon_quickreply"] forState:UIControlStateNormal];
                [button setImage:[UIImage imageNamed:@"tk_icon_keyboard"] forState:UIControlStateSelected];
                [button addTarget:self action:@selector(quickreplyButtonClick:) forControlEvents:(UIControlEventTouchUpInside)];
                button.hidden = YES;
                button;
            });
            [self addSubview:_replyButton];
            
            
            [self getQuickreplyDataList];
        }
        
        _emotionButton = ({
            UIButton *button = [UIButton  buttonWithType:(UIButtonTypeCustom)];
            
            [button setImage:[UIImage imageNamed:@"tk_icon_expression"] forState:UIControlStateNormal];
            [button setImage:[UIImage imageNamed:@"tk_icon_keyboard"] forState:UIControlStateSelected];
            [button addTarget:self action:@selector(emotionButtonClick:) forControlEvents:(UIControlEventTouchUpInside)];
            button;
        });
        [self addSubview:_emotionButton];
        
        if ([TKEduClassRoom shareInstance].roomJson.configuration.isChatAllowSendImage) {
            
            _picButton = ({
                UIButton *button = [UIButton  buttonWithType:(UIButtonTypeCustom)];

                [button setImage:[UIImage imageNamed:@"tk_icon_pic"] forState:UIControlStateNormal];
                [button setImage:[UIImage imageNamed:@"tk_icon_pic"] forState:UIControlStateSelected];

                [button addTarget:self action:@selector(pictureSendClick:) forControlEvents:(UIControlEventTouchUpInside)];
                button;
            });
            [self addSubview:_picButton];
        }
                
        _vLineView = [[UIView alloc] init];
        _vLineView.backgroundColor = [TKHelperUtil colorWithHexColorString:@"#E5E5E5"];
        [self addSubview:_vLineView];
    }
    
    return self;
}

- (void)loadNotificatio{
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(touchMainPage:)
                                                name:stouchMainPageNotification
                                              object:nil];
    
    
    //添加表情选中的通知    监听键盘
    // 监听表情选中的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(emotionDidSelected:) name:TKEmotionDidSelectedNotification object:nil];
    // 监听删除按钮点击的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(emotionDidDeleted:) name:TKEmotionDidDeletedNotification object:nil];
}
- (void)layoutSubviews{

    CGFloat sendWidth = 60;
    
    CGFloat inputWidth = self.width - sendWidth - 20;
    CGFloat inputX = 5;

    _inputField.frame = CGRectMake(inputX, 5, inputWidth, self.height - 10);
    _sendButton.frame = CGRectMake(_inputField.rightX + 5, 5, sendWidth, 34.);
    
    CGFloat frame_X = _inputField.rightX - 5;
    if (_replyButton && _replyButton.hidden == NO) {
        _replyButton.frame = CGRectMake(frame_X - emotionWidth, _sendButton.y, emotionWidth, _sendButton.height);
        frame_X = _replyButton.leftX;
    }
    
    _emotionButton.frame = CGRectMake(frame_X - emotionWidth, _sendButton.y, emotionWidth, _sendButton.height);
    frame_X = _emotionButton.leftX;
    
    if (_picButton && _picButton.hidden == NO) {
        _picButton.frame = CGRectMake(frame_X - emotionWidth, _emotionButton.y, emotionWidth, _sendButton.height);
        frame_X = _picButton.leftX;
    }
    
    CGFloat vLineX = frame_X - 8 - 1;
    _vLineView.frame = CGRectMake(vLineX, _sendButton.centerY - 10, 1, 20);
    
    _inputField.textContainerInset = UIEdgeInsetsMake(5, 2, 0, _inputField.rightX - vLineX - 5);
}


#pragma mark - 发送事件
- (void)sendButtonClick:(UIButton *)sender{
    if (!_inputField || !_inputField.realText || _inputField.realText.length == 0)
    {
        return;
    }
    
    if([[_inputField.realText stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]length]==0) {
        return;
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(sendMessage:)]) {

        [self.delegate sendMessage:_inputField.realText];
    }
    
    // 消息发出后，输入框高度复原
    self.inputField.text = @"";
    [self textViewDidChange:self.inputField];
    [self.inputField resignFirstResponder];
}

#pragma mark - 点击表情
- (void)emotionButtonClick:(UIButton *)sender{
        
    // 关闭键盘
    [self.inputField resignFirstResponder];
    
    // 切换按钮状态
    _replyButton.selected = NO;
    _emotionButton.selected = !sender.selected;
    _inputField.inputView = _emotionButton.selected ? self.kerboard : nil;
    
    // 更换完毕
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 打开键盘
        [self.inputField becomeFirstResponder];
    });
}

- (void) quickreplyButtonClick:(UIButton *) sender {
    
    if (self.quickreplyView.dataArray && self.quickreplyView.dataArray.count > 0) {
        
        // 关闭键盘
        [self.inputField resignFirstResponder];
        
        _emotionButton.selected = NO;
        _replyButton.selected = !sender.selected;
        self.inputField.inputView = _replyButton.selected ? self.quickreplyView : nil;
        
        // 更换完毕
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            // 打开键盘
            [self.inputField becomeFirstResponder];
        });
    } else {
        // 接口获取快捷回复数据
        [self getQuickreplyDataList];
    }
}

- (void)pictureSendClick:(UIButton *) sender {
    
    //判断是否自己被禁言
    BOOL disablechat = [TKUtil getBOOValueFromDic:[TKEduSessionHandle shareInstance].localUser.properties Key:sDisablechat];
    if (disablechat) {
        return;
    }
    
    // 关闭键盘
    [self.inputField resignFirstResponder];
    
    [TKEduSessionHandle shareInstance].updateImageUseType = TKUpdateImageUseType_Message;
    [[NSNotificationCenter defaultCenter] postNotificationName:sChoosePhotosUploadNotification object:sChoosePhotosUploadNotification];
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView {
    
    // 是否可以编辑
    return YES;
}



- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
        
    if ([text isEqualToString:@"\n"]){ //判断输入的字是否是回车，即按下return
        //在这里做你响应return键的代码
        [self sendButtonClick:nil];
        return NO; //这里返回NO，就代表return键值失效，即页面上按下return，不会出现换行，如果为yes，则输入页面会换行
    }
    
    return YES;
}

- (void)textViewDidChange:(UITextView *)textView {
    // 换行 逻辑
    
    CGRect frame = textView.frame;
    CGSize constraintSize = CGSizeMake(frame.size.width, MAXFLOAT);
    CGSize size = [textView sizeThatFits:constraintSize];
    if (size.height < 33.) {
        size.height = 33.;
    } else {
        size.height = fminf(size.height, 63) + 4;
    }
    
    textView.frame = CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, size.height);
    
    self.height = size.height + 10; // 10 是 textView 和 TKChattoolView 的高度差
    if (self.delegate && [self.delegate respondsToSelector:@selector(chatToolViewChangeHeight:)]) {
        
        [self.delegate chatToolViewChangeHeight: self.height];
    }
    
}

- (BOOL)textViewShouldEndEditing:(UITextView *)textView {

    [textView.textStorage endEditing];
    return YES;
}

#pragma mark - 表情键盘初始化
- (TKEmotionKeyboard *)kerboard {
    if (!_kerboard) {
        self.kerboard = [TKEmotionKeyboard keyboard];
        self.kerboard.frame = CGRectMake(0, 0, ScreenW, TKKeyBoardHeight);
        
    }
    return _kerboard;
}
        
- (void)touchMainPage:(NSNotification*)notify{

    [self.inputField resignFirstResponder];
}
- (void)emotionDidSelected:(NSNotification *)note
{
    TKEmotion *emotion = note.userInfo[TKSelectedEmotion];
    // 1.拼接表情
    [_inputField appendEmotion:emotion];
    
}

/**
 *  当点击表情键盘上的删除按钮时调用
 */
- (void)emotionDidDeleted:(NSNotification *)note
{
    // 往回删
    [_inputField deleteBackward];
}

// 快捷回复
- (TKChatQuickreplyView *)quickreplyView {
    
    if (nil == _quickreplyView) {
        _quickreplyView = [[TKChatQuickreplyView alloc] initWithFrame:CGRectMake(0, 0, ScreenW, fmaxf(216, ScreenH / 2))];
        _quickreplyView.delegate = self;
    }
    return _quickreplyView;
}

- (void)chatQuickreplySelectString:(NSString *)string {
        
    NSMutableAttributedString *attributedText = [[NSMutableAttributedString alloc] initWithAttributedString:_inputField.attributedText];
    NSAttributedString *attachString = [[NSAttributedString alloc] initWithString:string];
    
    // 记录表情的插入位置
    int insertIndex = (int)_inputField.selectedRange.location;
    
    // 插入表情图片到光标位置
    [attributedText insertAttributedString:attachString atIndex:insertIndex];
    
    // 设置字体
    [attributedText addAttribute:NSFontAttributeName value:_inputField.font range:NSMakeRange(0, attributedText.length)];
    [attributedText addAttribute:NSForegroundColorAttributeName value:[TKTheme colorWithPath:@"ClassRoom.TKChatViews.chatToolTextColor"] range:NSMakeRange(0, attributedText.length)];
    
    // 重新赋值(光标会自动回到文字的最后面)
    _inputField.attributedText = attributedText;
    
    // 让光标回到表情后面的位置
    _inputField.selectedRange = NSMakeRange(insertIndex + string.length, 0);
    
    [self textViewDidChange:_inputField];
}

- (void) getQuickreplyDataList {
    
    NSString * roleStr = [NSString stringWithFormat:@"%ld", (long)[TKEduSessionHandle shareInstance].localUser.role];
    
    [TKEduNetManager quickreplyCompanyid:[TKEduClassRoom shareInstance].roomJson.companyid langcode:[self getCurrentLanguage] roleType:roleStr aComplete:^int(id  _Nullable response) {
        
        if ([response isKindOfClass:[NSDictionary class]]) {
            
            NSDictionary * dict = (NSDictionary *)response;
            NSInteger status = [[dict objectForKey:@"status"] integerValue];
            
            if (0 == status) {
                
                NSArray * dataArr = [dict objectForKey:@"data"];
                if (dataArr && [dataArr isKindOfClass:[NSArray class]] && dataArr.count > 0) {
                    
                    self.quickreplyView.dataArray = dataArr;
                    self.replyButton.hidden = NO;
                    [self setNeedsLayout];
                    [self layoutIfNeeded];
                    
                    //[self quickreplyButtonClick:self.replyButton];
                    return 0;
                }
            }
        }
        
        self.replyButton.hidden = YES;
        [self setNeedsLayout];
        [self layoutIfNeeded];
        return 0;
    } aNetError:^int(id  _Nullable response) {
        
        self.replyButton.hidden = YES;
        [self setNeedsLayout];
        [self layoutIfNeeded];
        return 0;
    }];
}

- (NSString*) getCurrentLanguage {
    NSArray *language = [NSLocale preferredLanguages];
    if ([language objectAtIndex:0]) {
        NSString *currentLanguage = [language objectAtIndex:0];
        if ([currentLanguage length] >= 7 && [[currentLanguage substringToIndex:7] isEqualToString:@"zh-Hans"]) {
            return @"zh-cn";
        }
        
        if ([currentLanguage length] >= 7 && [[currentLanguage substringToIndex:7] isEqualToString:@"zh-Hant"]) {
            return @"zh-tw";
        }
        
        if ([currentLanguage length] >= 2) {
            return [currentLanguage substringToIndex:2];
        }
    }
    
    NSString *localeCode = [[NSLocale currentLocale] objectForKey:NSLocaleIdentifier];
    if (localeCode) {
        return localeCode;
    }
    
    return @"zh-cn";
}

@end
