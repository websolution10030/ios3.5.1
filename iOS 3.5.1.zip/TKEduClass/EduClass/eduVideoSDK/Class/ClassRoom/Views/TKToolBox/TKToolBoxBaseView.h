//
//  TKToolBoxBaseView.h
//  EduClass
//
//  Created by YI on 2019/1/16.
//  Copyright © 2019年 talkcloud. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
/** 本是图 必须 直接 添加在控件上 - 切记切记 */
@interface TKToolBoxBaseView : UIView

@end

NS_ASSUME_NONNULL_END
