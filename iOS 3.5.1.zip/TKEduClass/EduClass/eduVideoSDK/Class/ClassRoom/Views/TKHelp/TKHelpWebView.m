//
//  TKHelpWebView.m
//  EduClass
//
//  Created by talkcloud on 2020/3/30.
//  Copyright © 2020 talkcloud. All rights reserved.
//

#import "TKHelpWebView.h"
#import "TKEduClassRoom.h"

@implementation TKHelpWebView
/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

- (instancetype)initWithSuperView:(UIView *)superView
{
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    WKUserContentController *controller = [[WKUserContentController alloc] init];
    [controller addScriptMessageHandler:self name:@"jsBridge"];
    config.userContentController = controller;
    if (self = [self initWithFrame:CGRectZero configuration:config]) {
        self.status = 0;
        self.navigationDelegate = self;
        
        self.opaque = NO;
        self.backgroundColor = UIColor.clearColor;
        self.scrollView.backgroundColor = UIColor.clearColor;
        
        TKFakeView *fakeView = [[TKFakeView alloc] initWithFrame:superView.frame];
        fakeView.contentView = self;
        [superView addSubview:fakeView];
        [fakeView addSubview:self];
        
//        UIView *view = [[UIView alloc] init];
//        [fakeView addSubview:view];
//        [fakeView sendSubviewToBack:view];
//        [view mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.right.equalTo(self.mas_right).offset(-46);
//            make.bottom.equalTo(self.mas_bottom);
//            make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(46, 46)]);
//        }];
//        view.backgroundColor = UIColor.redColor;
        
        if (IS_PAD) {
            [self mas_makeConstraints:^(MASConstraintMaker *make) {
                make.right.equalTo(fakeView.mas_right);
                make.bottom.equalTo(fakeView.mas_bottom);
                make.width.equalTo(@(300));
                make.height.equalTo(self.mas_width).multipliedBy(4.0f / 3);
            }];
        } else {
            [self mas_makeConstraints:^(MASConstraintMaker *make) {
                make.top.equalTo(fakeView.mas_top);
                make.bottom.equalTo(fakeView.mas_bottom);
                make.right.equalTo(fakeView.mas_right);
                make.width.equalTo(self.mas_height).multipliedBy(3.0f / 4);
            }];
        }
        
        //@"https://demo.talk-cloud.net/static/ef_help_instance/index.html"
        [self loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[TKEduClassRoom shareInstance].roomJson.helpaddress]]];
    }
    
    return self;
}

- (void)reload
{
    //先加载空白页
    [self loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"about:blank"]]];
    [self loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[TKEduClassRoom shareInstance].roomJson.helpaddress]]];
}

- (void)evaluateJS
{
    //传身份信息
    NSDictionary *idDic = @{
        @"serial" : [[[TKRoomManager instance] getRoomProperty] objectForKey:@"serial"] ? [[[TKRoomManager instance] getRoomProperty] objectForKey:@"serial"] : @"",
        @"id" :  [TKRoomManager instance].localUser.peerID ?  [TKRoomManager instance].localUser.peerID : @"",
        @"nickname" : [TKRoomManager instance].localUser.nickName ? [TKRoomManager instance].localUser.nickName : @"",
        @"role" : @([TKRoomManager instance].localUser.role)
    };
    
    NSString *idString = [[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:idDic options:NSJSONWritingPrettyPrinted error:nil] encoding:NSUTF8StringEncoding];
    NSString *idJS = [NSString stringWithFormat:@"window.setInfo(%@)",idString];
    [self evaluateJavaScript:idJS completionHandler:nil];
    
    //传坐标信息
    NSMutableDictionary *positionDic = [@{
//        @"x":@"0",
//        @"y":@"0",
        @"width":@"46",
        @"height":@"46",
        @"text":@{
                @"help":TKMTLocalized(@"TKHelp.help"),
                @"loading":TKMTLocalized(@"TKHelp.loading"),
                @"contactus":TKMTLocalized(@"TKHelp.contactus"),
        }
    } mutableCopy];
    
    //pad求助按钮靠右下角
    if (IS_PAD) {
        [positionDic setValue:@"0" forKey:@"x"];
    }
    
    NSString *positionString = [[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:positionDic options:NSJSONWritingPrettyPrinted error:nil] encoding:NSUTF8StringEncoding];
    NSString *positionJS = [NSString stringWithFormat:@"window.setLayout(%@)",positionString];
    [self evaluateJavaScript:positionJS completionHandler:nil];
}

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message
{
    if ([message.name isEqualToString:@"jsBridge"]) {
        NSDictionary *data = [message.body objectForKey:@"data"];
        if ([data isKindOfClass:[NSString class]]) {
            data = [NSJSONSerialization JSONObjectWithData:[(NSString *)data dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingMutableLeaves error:nil];
        }
        NSString *status = [data objectForKey:@"status"];
        if (status) {
            self.status = status.intValue;
//            fakeView.backgroundColor = self.status == 2 ? [UIColor.blackColor colorWithAlphaComponent:0.3f] : UIColor.clearColor;
        }
    }
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation
{
    [self evaluateJS];
}

- (void)clear
{
    [self.configuration.userContentController removeScriptMessageHandlerForName:@"jsBridge"];
}

- (void)dealloc
{
    
}

@end

@implementation TKFakeView

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    if (self.contentView) {
        CGRect rect = CGRectMake(self.contentView.frame.size.width - 46 * (IS_PAD ? 1 : 2), self.contentView.frame.size.height - 46, 46, 46);
        
        if (self.contentView.status == 0) {
            if (CGRectContainsPoint([self.contentView convertRect:rect toView:self], point)) {
                return [super hitTest:point withEvent:event];
            } else {
                return nil;
            }
        } else if (self.contentView.status == 2) {
            if (CGRectContainsPoint(self.contentView.frame, point)) {
                return [super hitTest:point withEvent:event];
            } else {
                [self.contentView reload];
                return nil;
            }
        } else {
            return nil;
        }
    }
    return nil;
}

@end
