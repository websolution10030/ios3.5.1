//
//  TKHelpWebView.h
//  EduClass
//
//  Created by talkcloud on 2020/3/30.
//  Copyright © 2020 talkcloud. All rights reserved.
//

#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TKHelpWebView : WKWebView <WKScriptMessageHandler, WKNavigationDelegate>

@property (nonatomic, assign) int status;
- (instancetype)initWithSuperView:(UIView *)superView;

- (void)reload;

- (void)clear;
@end

@interface TKFakeView: UIView
@property (nonatomic, weak) TKHelpWebView *contentView;
@end

NS_ASSUME_NONNULL_END
