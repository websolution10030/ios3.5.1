//
//  TKTrophyButton.h
//  EduClass
//
//  Created by lyy on 2018/5/25.
//  Copyright © 2018年 talkcloud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TKTrophyButton : UIButton

@end
