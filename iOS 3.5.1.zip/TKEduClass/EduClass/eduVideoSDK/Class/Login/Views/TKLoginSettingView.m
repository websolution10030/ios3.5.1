//
//  TKLoginSettingView.m
//  EduClass
//
//  Created by Evan on 2020/3/24.
//  Copyright © 2020 talkcloud. All rights reserved.
//

#define CheckProportion (ScreenH < ScreenW ? ScreenW/1024.0 : ScreenH/1024.0)
#define kAppStoreFormat @"https://itunes.apple.com/app/id%ld"

#import "TKLoginSettingView.h"
#import "TKSPContentView.h"

@interface TKLoginSettingView ()

@property (nonatomic, strong) TKSPContentView *contentView;

@property (nonatomic, strong) UIView *backView;
@property (nonatomic, strong) UIImageView *logoIamge;

@property (nonatomic, strong) UIView *userAgreementCell;// 用户协议
@property (nonatomic, strong) UIView *privacyAgreementCell;// 隐私协议
@property (nonatomic, strong) UIView *checkDeviceCell; // 开启设备检测
@property (nonatomic, strong) UIView *versionUpdateCell; // 版本更新
@property (nonatomic, strong) UILabel *versionLabel;//版本号

@property (nonatomic, strong) UILabel *CheckDevicReminderLa;

@property (nonatomic,assign) CGFloat property;
@property (nonatomic, strong) UISwitch *checkDeviceSwitch;

@property (nonatomic,assign) UIInterfaceOrientation interfaceOriention;

@end

@implementation TKLoginSettingView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = RGBCOLOR(246, 248, 248);
        
        [self addSubview:self.backView];
        [self addSubview:self.logoIamge];
        [self addSubview:self.userAgreementCell];
        [self addSubview:self.privacyAgreementCell];
        [self addSubview:self.checkDeviceCell];
        [self addSubview:self.versionUpdateCell];
//        [self addSubview:self.versionLabel];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(orientChange:) name:UIDeviceOrientationDidChangeNotification object:nil];
        
    }
    return self;
}

- (void)orientChange:(NSNotification *)notification {
    
    self.interfaceOriention = [UIApplication sharedApplication].statusBarOrientation;
}


- (void)setup {
    
}


- (void)layoutSubviews {
    
    
    self.contentView.frame = self.frame;
    
    self.backView.frame = CGRectMake(0, 0, CGRectGetWidth(self.frame), 66 );
    
    self.logoIamge.frame  = CGRectMake(0, CGRectGetHeight(self.backView.frame) + 60 * CheckProportion, CGRectGetWidth(self.frame), 103);
    
    
    if (IS_IPHONE && ScreenH < ScreenW) {
        self.logoIamge.hidden = YES;
        self.property = 0.8;
        _CheckDevicReminderLa.numberOfLines = 1;
        self.userAgreementCell.frame = CGRectMake(24, CGRectGetMaxY(self.backView.frame) + 16 * CheckProportion, CGRectGetWidth(self.frame) - 48, 63);
//        [self.userAgreementCell mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.centerX.equalTo(self);
//            make.top.equalTo(_backView.mas_bottom).offset(16 * CheckProportion);
//            make.left.equalTo(self).offset(24);
//            make.right.equalTo(self.mas_right).offset(-24);
//            make.height.equalTo(@(63));
//        }];
    }else {
        self.logoIamge.hidden = NO;
        self.property = 1;
        _CheckDevicReminderLa.numberOfLines = 2;
        
//        [self.userAgreementCell mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.centerX.equalTo(self);
//            make.top.equalTo(_logoIamge.mas_bottom).offset(60 * CheckProportion);
//            make.left.equalTo(self).offset(24);
//            make.right.equalTo(self.mas_right).offset(-24);
//            make.height.equalTo(@(63));
//        }];
        self.userAgreementCell.frame = CGRectMake(24, CGRectGetMaxY(self.logoIamge.frame) + 60 * CheckProportion, CGRectGetWidth(self.frame) - 48, 63);
    }
    
    self.privacyAgreementCell.frame = CGRectMake(24, CGRectGetMaxY(self.userAgreementCell.frame) + 16, CGRectGetWidth(self.frame) - 48, 63 * _property);
    
    self.checkDeviceCell.frame = CGRectMake(24, CGRectGetMaxY(self.privacyAgreementCell.frame) + 16, CGRectGetWidth(self.frame) - 48, 89 * _property);
    
    
    self.checkDeviceSwitch.y = (89 * _property - 30)/2;
    _checkDeviceSwitch.x = CGRectGetWidth(self.frame) - 24 - 15 - 75;
    _checkDeviceSwitch.size = CGSizeMake(50, 30);
    
    
    self.versionUpdateCell.frame = CGRectMake(24, CGRectGetMaxY(self.checkDeviceCell.frame) + 16, CGRectGetWidth(self.frame) - 48, 63 * _property);
    
//    [self.privacyAgreementCell mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.centerX.equalTo(self);
//        make.top.equalTo(_userAgreementCell.mas_bottom).offset(16 * _property);
//        make.left.equalTo(self).offset(24);
//        make.right.equalTo(self.mas_right).offset(-24);
//        make.height.equalTo(@(63 * _property));
//    }];
    
    
//    [self.checkDeviceCell mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.centerX.equalTo(self);
//        make.top.equalTo(_privacyAgreementCell.mas_bottom).offset(16 * _property);
//        make.left.equalTo(self).offset(24);
//        make.right.equalTo(self.mas_right).offset(-24);
//        make.height.equalTo(@(89 * _property));
//    }];
    
//    [self.versionUpdateCell mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.centerX.equalTo(self);
//        make.top.equalTo(_checkDeviceCell.mas_bottom).offset(16 * _property);
//        make.left.equalTo(self).offset(24);
//        make.right.equalTo(self.mas_right).offset(-24);
//        make.height.equalTo(@(63 * _property));
//    }];
    
    
//    self.versionLabel.frame   = CGRectMake(0, [TKUtil isiPhoneX]?CGRectGetHeight(self.frame) -40-17:CGRectGetHeight(self.frame) - 40, CGRectGetWidth(self.frame), 40);
}

#pragma mark - cell的点击事件
- (void)backButtonAction:(UIButton *)sender {
    [self dismissAlert];
}

- (void)userAgreementAction:(UIButton *)sender {
    self.contentView.taget = 1;
    [self.contentView show:self];
    
}

- (void)privacyAgreementAction:(UIButton *)sender {
    self.contentView.taget = 2;
    [self.contentView show:self];
}


- (void)versionUpdateAction:(UIButton *)sender {
    NSString *appStoreURL = [NSString stringWithFormat:kAppStoreFormat, [[[NSBundle mainBundle] objectForInfoDictionaryKey:@"APP_STORE_ID"] longValue]];
    NSURL *url = [NSURL URLWithString:appStoreURL];
    [[UIApplication sharedApplication] openURL:url];
}

- (void)checkDeviceSwitchAction:(UISwitch *)mySwitch {
    if (mySwitch.on == YES) {
        [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"isShowDeveiceCheckView"];
    }else {
        [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"isShowDeveiceCheckView"];
    }
}

- (void)show:(UIView *)view
{
    [TKMainWindow addSubview:self];
    CGRect rect = self.frame;
    self.frame = CGRectMake(CGRectGetWidth(self.frame), rect.origin.y, rect.size.width, rect.size.height);
    [TKMainWindow addSubview:self];
    
    [UIView animateWithDuration:0.3f animations:^{
        self.frame = CGRectMake(0, 0, rect.size.width, rect.size.height);
    }];
}


- (void)dismissAlert
{
    [UIView animateWithDuration:0.3f animations:^{
        
        CGRect rect = self.frame;
        self.frame = CGRectMake(CGRectGetWidth(self.frame), rect.origin.y, rect.size.width, rect.size.height);
        
    }completion:^(BOOL finished){
        
        [self removeFromSuperview];
        
    }];
    
}


#pragma mark - setter
- (TKSPContentView *)contentView {
    if (!_contentView) {
        _contentView = [[TKSPContentView alloc] initWithFrame:self.frame];
    }
    return _contentView;
}

- (UIView *)backView {
    if (!_backView) {
        _backView = [[UIView alloc] init];
        _backView.backgroundColor = UIColor.whiteColor;
        _backView.layer.cornerRadius = 5;
        UIButton *backbutton = [UIButton buttonWithType:UIButtonTypeCustom];
        [backbutton setImage:[UIImage imageNamed:@"tk_loginSetting_back"] forState:UIControlStateNormal];
        [backbutton addTarget:self action:@selector(backButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [_backView addSubview:backbutton];
        
        [backbutton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(_backView).offset(23);
            make.centerY.equalTo(_backView).offset(10);
            make.size.mas_equalTo(CGSizeMake(20, 20));
        }];
        
        UILabel *titleLa = [[UILabel alloc] init];
        titleLa.text = TKMTLocalized(@"Login.setting");
        titleLa.font = [UIFont systemFontOfSize:16];
        titleLa.textColor = RGBCOLOR(71, 71, 75);
        [_backView addSubview:titleLa];
        [titleLa mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(_backView);
            make.centerY.equalTo(_backView).offset(10);
        }];
    }
    return _backView;
}

- (UIImageView *)logoIamge {
    if (!_logoIamge) {
        _logoIamge = [[UIImageView alloc] init];
        _logoIamge.image = [UIImage imageNamed:@"tk_login_logo"];
        _logoIamge.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _logoIamge;
}


- (UIView *)userAgreementCell {
    if (!_userAgreementCell) {
        _userAgreementCell = [self creatCellViewImage:@"tk_loginSetting_userAgreement" title:TKMTLocalized(@"Login.userAgreement") buttonName:@"tk_login_nextbutton" action:@selector(userAgreementAction:)];
    }
    return _userAgreementCell;
}

- (UIView *)privacyAgreementCell {
    if (!_privacyAgreementCell) {
        _privacyAgreementCell = [self creatCellViewImage:@"tk_loginSetting_PrivacyAgreement" title:TKMTLocalized(@"Login.privacyAgreement") buttonName:@"tk_login_nextbutton" action:@selector(privacyAgreementAction:)];
    }
    return _privacyAgreementCell;
}

- (UIView *)versionUpdateCell {
    if (!_versionUpdateCell) {
        _versionUpdateCell = [self creatCellViewImage:@"tk_loginSetting_update" title:TKMTLocalized(@"Login.versionUpdate") buttonName:@"tk_login_nextbutton" action:@selector(versionUpdateAction:)];
    }
    return _versionUpdateCell;
}

- (UILabel *)CheckDevicReminderLa {
    if (!_CheckDevicReminderLa) {
        _CheckDevicReminderLa = [[UILabel alloc] init];
        _CheckDevicReminderLa.text = TKMTLocalized(@"Login.deviceDetectionRe");
        _CheckDevicReminderLa.font = [UIFont systemFontOfSize:13];
        _CheckDevicReminderLa.textColor = RGBCOLOR(149, 151, 164);
        _CheckDevicReminderLa.numberOfLines = 2;
    }
    return _CheckDevicReminderLa;
}

- (UIView *)checkDeviceCell {
    if (!_checkDeviceCell) {
        _checkDeviceCell = [[UIView alloc] init];
        _checkDeviceCell.backgroundColor = UIColor.whiteColor;
        _checkDeviceCell.layer.cornerRadius = 7;
        UIImageView *imageView = [[UIImageView alloc] init];
        imageView.image = [UIImage imageNamed:@"tk_loginSetting_checkDevice"];
        [_checkDeviceCell addSubview:imageView];
        
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(_checkDeviceCell).offset(23);
            make.top.equalTo(_checkDeviceCell).offset(23);
            make.size.mas_equalTo(CGSizeMake(20, 20));
        }];
        
        UILabel *titleLa = [[UILabel alloc] init];
        titleLa.text = TKMTLocalized(@"Login.deviceDetection");
        titleLa.font = [UIFont systemFontOfSize:14];
        titleLa.textColor = RGBCOLOR(82, 79, 102);
        [_checkDeviceCell addSubview:titleLa];
        [titleLa mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(imageView.mas_right).offset(10);
            make.centerY.equalTo(imageView);
        }];
        
        self.checkDeviceSwitch.y = (89 * _property - 30)/2;
        _checkDeviceSwitch.x = CGRectGetWidth(self.frame) - 24 - 15 - 70;
        _checkDeviceSwitch.size = CGSizeMake(50, 30);
        
        [_checkDeviceCell addSubview:self.checkDeviceSwitch];
        
//        [_checkDeviceSwitch mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.centerY.equalTo(_checkDeviceCell);
//            make.right.equalTo(_checkDeviceCell.mas_right).offset(-15);
//        }];
        
        
        [_checkDeviceCell addSubview:self.CheckDevicReminderLa];
        [_CheckDevicReminderLa mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(titleLa);
            make.top.equalTo(titleLa.mas_bottom).offset(12 * CheckProportion);
            make.right.equalTo(_checkDeviceSwitch.mas_left).offset(-30 * CheckProportion);
        }];
    }
    return _checkDeviceCell;
}

- (UISwitch *)checkDeviceSwitch {
    if (!_checkDeviceSwitch) {
        
        NSString *isCheckDeviceOn = [[NSUserDefaults standardUserDefaults] objectForKey:@"isShowDeveiceCheckView"];
        
        self.checkDeviceSwitch = [[UISwitch alloc] init];
        self.checkDeviceSwitch.onTintColor = RGBCOLOR(0, 119, 225);
        [self.checkDeviceSwitch addTarget:self action:@selector(checkDeviceSwitchAction:) forControlEvents:(UIControlEventValueChanged)];
        self.checkDeviceSwitch.on = YES;
        if ([isCheckDeviceOn isEqualToString:@"0"]) {
            self.checkDeviceSwitch.on = NO;
        }
    }
    return _checkDeviceSwitch;
}


- (UILabel *)versionLabel
{
    if (!_versionLabel) {
        _versionLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _versionLabel.textAlignment = NSTextAlignmentCenter;
        _versionLabel.textColor = [TKHelperUtil colorWithHexColorString:@"8C8E97"];
        _versionLabel.text =  [NSString stringWithFormat:@"V%@",[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]];
        _versionLabel.font = [UIFont systemFontOfSize:13];
    }
    return _versionLabel;
}


- (UIView *)creatCellViewImage:(NSString *)imageName title:(NSString *)title buttonName:(NSString *)buttonName action:(SEL)action {
    UIView *cellView = [[UIView alloc] init];
    cellView.backgroundColor = UIColor.whiteColor;
    cellView.layer.cornerRadius = 7;
    
    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.image = [UIImage imageNamed:imageName];
    [cellView addSubview:imageView];
    
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(cellView).offset(23);
        make.centerY.equalTo(cellView);
        make.size.mas_equalTo(CGSizeMake(20, 20));
    }];
    
    UILabel *titleLa = [[UILabel alloc] init];
    titleLa.text = title;
    titleLa.textColor = RGBCOLOR(82, 79, 102);
    titleLa.font = [UIFont systemFontOfSize:14];
    titleLa.textColor = RGBCOLOR(82, 79, 102);
    [cellView addSubview:titleLa];
    [titleLa mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(imageView.mas_right).offset(10);
        make.centerY.equalTo(imageView);
    }];
    
    UIImageView *nextImage = [[UIImageView alloc] init];
    nextImage.image = [UIImage imageNamed:buttonName];
    [cellView addSubview:nextImage];
    [nextImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(cellView.mas_right).offset(-15);
        make.centerY.equalTo(cellView);
        make.size.mas_equalTo(CGSizeMake(9, 15));
    }];
    
    
    UIButton *nextBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [nextBtn addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [cellView addSubview:nextBtn];
    
    [nextBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(cellView.mas_right);
//        make.centerY.equalTo(cellView);
//        make.size.mas_equalTo(CGSizeMake(44, 44));
        make.top.equalTo(cellView);
        make.left.equalTo(cellView);
        make.bottom.equalTo(cellView.mas_bottom);
    }];
    
    
    return cellView;
}






@end
