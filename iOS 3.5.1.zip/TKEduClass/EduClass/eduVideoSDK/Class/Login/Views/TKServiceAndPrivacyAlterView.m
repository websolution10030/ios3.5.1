//
//  TKServiceAndPrivacyAlterView.m
//  EduClass
//
//  Created by Evan on 2020/3/16.
//  Copyright © 2020 talkcloud. All rights reserved.
//

#define CheckProportion (ScreenH < ScreenW ? ScreenW/1024.0 : ScreenH/1024.0)

#define selfviewWidth (ScreenH < ScreenW ? ScreenH : ScreenW)

#import "TKServiceAndPrivacyAlterView.h"

@interface TKServiceAndPrivacyAlterView  ()<UITextViewDelegate>

@property (nonatomic, strong) UIView *contentView;

@property (nonatomic, strong) UILabel *titleLa;
@property (nonatomic, strong) UITextView *detailsLa;

@property (nonatomic, strong) UIButton *agreeBtn;
@property (nonatomic, strong) UIButton *disagreeBtn;

@property (nonatomic, strong) NSArray *stringArr;
@property (nonatomic, strong) NSMutableArray *rangeMarry;

@end

@implementation TKServiceAndPrivacyAlterView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5f];
        
        [self addSubview:self.contentView];
        [self.contentView addSubview:self.titleLa];
        [self.contentView addSubview:self.detailsLa];
        [self.contentView addSubview:self.agreeBtn];
        [self.contentView addSubview:self.disagreeBtn];
        
        
        [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(self);
            make.height.equalTo(@(350));
            make.width.equalTo(@(selfviewWidth - 60));
        }];
        
       
        
        
        
        [_titleLa mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.contentView).offset(30 * CheckProportion);
            make.left.equalTo(self.contentView).offset(30 * CheckProportion);
             make.right.equalTo(self.contentView.mas_right).offset(-30 * CheckProportion);
        }];
        
        [_agreeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.contentView.mas_bottom).offset(-40 * CheckProportion);
            make.right.equalTo(self.contentView.mas_right).offset(-30 * CheckProportion);
            make.size.mas_equalTo(CGSizeMake(80 * CheckProportion, 44 * CheckProportion));
        }];
        
        
        [_disagreeBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(_agreeBtn);
            make.right.equalTo(_agreeBtn.mas_left).offset(-40 * CheckProportion);
            make.size.mas_equalTo(CGSizeMake(100 * CheckProportion, 44 * CheckProportion));
        }];
        
        [_detailsLa mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(_titleLa.mas_bottom).offset(30 * CheckProportion);
            make.left.equalTo(_titleLa);
            make.right.equalTo(self.contentView).offset(-30 * CheckProportion);
            make.bottom.equalTo(_agreeBtn.mas_top).offset(-30 * CheckProportion);
        }];
        
    }
    return self;
}

- (void)agreeButtonAction:(UIButton *)sender {
    [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"isShowServiceAgreementAndprivacyPolicy"];
    [self removeFromSuperview];
}

- (void)disagreeButtonAction:(UIButton *)sender {
    [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"isShowServiceAgreementAndprivacyPolicy"];
    exit(0);
}


- (UIView *)contentView {
    if (!_contentView) {
        _contentView = [[UIView alloc] init];
        _contentView.layer.cornerRadius = 5;
        _contentView.backgroundColor = [UIColor whiteColor];
    }
    return _contentView;
}


- (NSArray *)stringArr {
    if (!_stringArr) {
        _stringArr = [NSArray array];
    }
    return _stringArr;
}

- (NSMutableArray *)rangeMarry {
    if (!_rangeMarry) {
        _rangeMarry = [NSMutableArray array];
    }
    return _rangeMarry;
}


- (UILabel *)titleLa {
    if (!_titleLa) {
        _titleLa = [[UILabel alloc] init];
        _titleLa.text = TKMTLocalized(@"Login.userPrivacyAgreementAlterTitle");
        [_titleLa setFont:[UIFont fontWithName:@"Helvetica-BoldOblique" size:20]];
        _titleLa.textColor = [UIColor blackColor];
        _titleLa.backgroundColor = UIColor.whiteColor;
        _titleLa.numberOfLines = 0;
    }
    return _titleLa;
}

- (UITextView *)detailsLa {
    if (!_detailsLa) {
        _detailsLa = [[UITextView alloc] init];
        _detailsLa.backgroundColor = UIColor.whiteColor;
        _detailsLa.editable = NO;
        _detailsLa.scrollEnabled = NO;
        _detailsLa.selectable = YES;
        _detailsLa.textColor = UIColor.blackColor;
        _detailsLa.delegate = self;
        NSMutableAttributedString *text = [[NSMutableAttributedString alloc]initWithString:TKMTLocalized(@"Login.userPrivacyAgreementAlter")];
        _detailsLa.attributedText = text;
        [_detailsLa setFont:[UIFont systemFontOfSize:16]];
//        NSArray *tempArr = @[@"《服务协议》", @"《隐私政策》"];
//        [self responseTextWithClickStringArray:tempArr];
        
//        UITapGestureRecognizer *tapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapped:)];
//        [_detailsLa addGestureRecognizer:tapRecognizer];
    }
    return _detailsLa;
}

- (UIButton *)agreeBtn {
    if (!_agreeBtn) {
        _agreeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_agreeBtn setTitle:TKMTLocalized(@"Login.userPrivacyAgreementButton") forState:UIControlStateNormal];
        _agreeBtn.backgroundColor = RGBACOLOR(0, 119, 255, 1);
        _agreeBtn.layer.cornerRadius = 22 * CheckProportion;
        [_agreeBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _agreeBtn.titleLabel.font = [UIFont systemFontOfSize:20 * CheckProportion];
        [_agreeBtn addTarget:self action:@selector(agreeButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _agreeBtn;
}

- (UIButton *)disagreeBtn {
    if (!_disagreeBtn) {
        _disagreeBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_disagreeBtn setTitle:TKMTLocalized(@"Login.userPrivacyDisagreementButton") forState:UIControlStateNormal];
        _disagreeBtn.backgroundColor = UIColor.clearColor;
        [_disagreeBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        _disagreeBtn.titleLabel.font = [UIFont systemFontOfSize:14];
        [_disagreeBtn addTarget:self action:@selector(disagreeButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _disagreeBtn;
}


- (void)responseTextWithClickStringArray:(NSArray<NSString *> *)aStringArray{
    _stringArr = aStringArray;
    NSMutableAttributedString *attributedStr = [[NSMutableAttributedString alloc]initWithString:self.detailsLa.text];
    for (NSString *tempStr in aStringArray) {
        NSRange tempRange = [self.detailsLa.text rangeOfString:tempStr];
        [self.rangeMarry addObject:NSStringFromRange(tempRange)];
        [attributedStr addAttribute:NSLinkAttributeName value:tempStr range:tempRange];
//        [attributedStr addAttribute:NSUnderlineStyleAttributeName value:[NSNumber numberWithInteger:NSUnderlineStyleNone] range:tempRange];// 下划线
    }
    [attributedStr addAttribute:NSFontAttributeName value:[UIFont systemFontOfSize:IS_PAD ? 18 : 16] range:NSMakeRange(0, attributedStr.length)];
    self.detailsLa.attributedText = attributedStr;
}

// TextView的点击事件
- (void)tapped:(UIGestureRecognizer *)ges{
    if ([ges isKindOfClass:[UITapGestureRecognizer class]]) {
        UITextView* textView = (UITextView *)ges.view;
        CGPoint tapLocation = [ges locationInView:textView];
        UITextPosition *textPosition = [textView closestPositionToPoint:tapLocation];
        NSDictionary *atts = [textView textStylingAtPosition:textPosition inDirection:UITextStorageDirectionForward];
        NSURL *url = atts[NSLinkAttributeName];
        NSString *selectStr = [NSString stringWithFormat:@"%@",url];
        if(url) {
//            NSLog(@"%@",selectStr);
            if (self.textBlock) {
                self.textBlock(selectStr);
            }
        }
    }
}


//- (BOOL)textView:(UITextView *)textView shouldInteractWithURL:(NSURL *)URL inRange:(NSRange)characterRange {
//    NSString *tempRangeStr = NSStringFromRange(characterRange);
//    if ([self.rangeMarry containsObject:tempRangeStr]) {
//        NSString *selectStr = [self.detailsLa.text substringWithRange:characterRange];
//        NSLog(@"%@",selectStr);
//        if (self.textBlock) {
//            self.textBlock(selectStr);
//        }
//    }
//    return YES;
//}


@end
