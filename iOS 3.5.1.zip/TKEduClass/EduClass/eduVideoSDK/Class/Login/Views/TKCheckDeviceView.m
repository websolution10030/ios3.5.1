//
//  TKCheckDeviceView.m
//  EduClass
//
//  Created by Evan on 2020/4/13.
//  Copyright © 2020 talkcloud. All rights reserved.
//

#define CheckProportion (ScreenH < ScreenW ? ScreenW/1024.0 : ScreenH/1024.0)
#define Fit(height) (IS_PAD ? (height) : (height) *0.6)
#define VIdeoHeight (IS_PAD ? 140 : 70)

#import "TKCheckDeviceView.h"
#import <AVFoundation/AVFoundation.h>
#import "TKIPhoneTypeString.h"


@interface TKCheckDeviceView ()<AVCaptureVideoDataOutputSampleBufferDelegate>
{
    AVAudioRecorder *recorder;
    NSTimer *levelTimer;
    AVCaptureSession *session;
}

@property (nonatomic, strong) AVAudioSession             *audioSession;
@property (nonatomic, strong) AVCaptureVideoPreviewLayer *preLayer;


@property (nonatomic, strong) UILabel        *videoTopTitleLa;
@property (nonatomic, strong) UIView         *smallVideoView; // 视频检测

@property (nonatomic, strong) UIImageView    *videoStatusImg;
@property (nonatomic, strong) UILabel        *videoBottomTitleLa;
@property (nonatomic, strong) UISwitch       *videoSwith;// 视频开关

@property (nonatomic, strong) UILabel        *audioTitleLa;
@property (nonatomic, strong) UIImageView    *audioView;// 音频检测
@property (nonatomic, strong) UILabel        *audioReminderLa;

@property (nonatomic, strong) UILabel        *volumeTitleLa;
@property (nonatomic, strong) UIImageView    *volumeImage;
@property (nonatomic, strong) UIProgressView *volumeprogreView;// 当前系统音量
@property (nonatomic, strong) UILabel        *volumePercentLa;
@property (nonatomic, strong) UILabel        *volumeReminderLa;

@property (nonatomic, strong) UIImageView    *imageView;


@property (nonatomic, strong) UIButton       *sureBtn;

@property (nonatomic, strong) UIButton *isHiddenDeviceViewBtn;

@property (nonatomic, strong) UIButton *microphoneOffReminder;

@property (nonatomic, strong) UIImageView  *microphoneOffReminderImg;
@property (nonatomic, strong) UILabel      *microphoneOffReminderLa;


@property (nonatomic, strong) UIImageView  *ConformDeviceReminderImg;
@property (nonatomic, strong) UILabel      *ConformDeviceReminderLa;

@property (nonatomic,assign) UIInterfaceOrientation interfaceOriention;
@end

@implementation TKCheckDeviceView


- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    
    return UIInterfaceOrientationMaskAllButUpsideDown;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(orientChange:) name:UIDeviceOrientationDidChangeNotification object:nil];
        
        
        // 检测设备横竖屏状态
        self.interfaceOriention = [UIApplication sharedApplication].statusBarOrientation;
        
        if (self.interfaceOriention == UIInterfaceOrientationLandscapeLeft || self.interfaceOriention == UIInterfaceOrientationLandscapeRight) {
            [self setLandscapeRightUI];
        }else {
            [self setupUI];
        }
        
        
        // 获取当前x系统音量
        self.audioSession = [AVAudioSession sharedInstance];
        /*创建录音 */
        [self creatAudioSession];
        
        /* 创建视频 */
        [self creatVideo];
        
        if (![TKUtil deviceisConform] && IS_PAD) {
            self.ConformDeviceReminderLa.hidden = NO;
            self.ConformDeviceReminderImg.hidden = NO;
            self.ConformDeviceReminderLa.text = [NSString stringWithFormat:@"%@%@%@", TKMTLocalized(@"TKDeviceCheck.conformDeviceReminderFornt"), [TKIPhoneTypeString checkIPhoneType], TKMTLocalized(@"TKDeviceCheck.conformDeviceReminderBack")];
        }
        
        
    }
    return self;
}

- (void)layoutSubviews {
    self.frame = CGRectMake(0, 0, ScreenW, ScreenH);
}

- (void)orientChange:(NSNotification *)notification {

//    UIDeviceOrientation  orient = [UIDevice currentDevice].orientation;
    
    self.interfaceOriention = [UIApplication sharedApplication].statusBarOrientation;
    
    self.preLayer.connection.videoOrientation = (AVCaptureVideoOrientation)self.interfaceOriention;
    switch (self.interfaceOriention) {
        case UIDeviceOrientationLandscapeLeft:
        case UIDeviceOrientationLandscapeRight: {
            [self setLandscapeRightUI];
        }
            break;
        case UIDeviceOrientationPortrait:
        case UIDeviceOrientationPortraitUpsideDown:{
            [self setupUI];
        }
            break;
            
        default:
            break;
    }
    
}


#pragma mark - 竖屏界面
- (void)setupUI {
    
    [self.videoTopTitleLa removeFromSuperview];
    [self.smallVideoView removeFromSuperview];
    [self.imageView removeFromSuperview];
    [self.preLayer removeFromSuperlayer];
    [self.videoStatusImg removeFromSuperview];
    [self.videoBottomTitleLa removeFromSuperview];
    [self.audioTitleLa removeFromSuperview];
    [self.audioView removeFromSuperview];
    [self.audioReminderLa removeFromSuperview];
    [self.volumeTitleLa removeFromSuperview];
    [self.volumeImage removeFromSuperview];
    [self.volumeprogreView removeFromSuperview];
    [self.volumeReminderLa removeFromSuperview];
    [self.sureBtn removeFromSuperview];
    [self.ConformDeviceReminderImg removeFromSuperview];
    [self.ConformDeviceReminderLa removeFromSuperview];

    self.frame = CGRectMake(0, 0, ScreenW, ScreenW);
    
    // 视频检测
    self.videoTopTitleLa.frame = CGRectMake(VIdeoHeight * CheckProportion, 70 * CheckProportion, 200, 30);
    [self addSubview:self.videoTopTitleLa];
    
    
    
    self.smallVideoView.frame = CGRectMake(VIdeoHeight * CheckProportion, 70 * CheckProportion + 45, ScreenW - VIdeoHeight * 2 * CheckProportion, (ScreenW - VIdeoHeight * 2 * CheckProportion) * 3 / 4);
    [self addSubview:self.smallVideoView];
    
    
    self.imageView.frame = self.smallVideoView.frame;
    [self addSubview:self.imageView];
    
    
    [self.layer addSublayer:self.preLayer];
    self.preLayer.frame = CGRectMake(VIdeoHeight * CheckProportion, 70 * CheckProportion + 45 , ScreenW - VIdeoHeight * 2 * CheckProportion, (ScreenW - VIdeoHeight * 2 * CheckProportion) * 3 / 4);
    
    
    [self addSubview:self.videoStatusImg];
    
    [self.videoStatusImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_smallVideoView.mas_bottom).offset(12 * CheckProportion);
        make.left.equalTo(_smallVideoView);
        make.size.mas_equalTo(CGSizeMake(16 * CheckProportion, 16 * CheckProportion));
    }];
    
    
    // 对话框显示 开关
    [self addSubview:self.videoBottomTitleLa];
    
    [_videoBottomTitleLa mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_videoStatusImg);
        make.left.equalTo(_videoStatusImg.mas_right).offset(10 * CheckProportion);
        make.right.equalTo(self.smallVideoView.mas_right);
    }];
    
        
        
    // 麦克风检测
    [self addSubview:self.audioTitleLa];
    
    [_audioTitleLa mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_videoStatusImg.mas_bottom).offset(30 * CheckProportion);
        make.left.equalTo(_videoStatusImg);
        make.right.equalTo(self.smallVideoView.mas_right);
    }];
    
    
    
    [self addSubview:self.audioView];
    
    [_audioView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_audioTitleLa.mas_bottom).offset(15 * CheckProportion);
        make.left.equalTo(_audioTitleLa.mas_left);
        make.size.mas_equalTo(CGSizeMake(225 * CheckProportion, 22 * CheckProportion));
    }];
    
    [self addSubview:self.audioReminderLa];
    [self.audioReminderLa mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_audioView.mas_bottom).offset(15 * CheckProportion);
        make.left.equalTo(_audioView);
        make.right.equalTo(self.smallVideoView.mas_right);
    }];
    
    
    [self addSubview:self.microphoneOffReminderImg];
    [_microphoneOffReminderImg mas_makeConstraints:^(MASConstraintMaker *make) {
       make.top.equalTo(_audioReminderLa.mas_bottom).offset(15 * CheckProportion);
        make.left.equalTo(_audioReminderLa);
        make.size.mas_equalTo(CGSizeMake(16 * CheckProportion, 16 * CheckProportion));
    }];
    
    [self addSubview:self.microphoneOffReminderLa];
    [_microphoneOffReminderLa mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_microphoneOffReminderImg);
        make.left.equalTo(_microphoneOffReminderImg.mas_right).offset(5);
        make.right.equalTo(self.smallVideoView.mas_right);
    }];
    
    
    // 扬声器检测
    [self addSubview:self.volumeTitleLa];
    
    [_volumeTitleLa mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_audioReminderLa.mas_bottom).offset(50 * CheckProportion);
        make.left.equalTo(_audioReminderLa);
    }];
    
    
    [self addSubview:self.volumeImage];
    
    [_volumeImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_volumeTitleLa.mas_bottom).offset(15 * CheckProportion);
        make.left.equalTo(_volumeTitleLa.mas_left);
        make.size.mas_equalTo(CGSizeMake(23 * CheckProportion, 21 * CheckProportion));
    }];
    
    
    
    [self addSubview:self.volumeprogreView];
    
    [_volumeprogreView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_volumeImage);
        make.left.equalTo(_volumeImage.mas_right).offset(11 * CheckProportion);
        make.size.mas_equalTo(CGSizeMake(191 * CheckProportion, 5 * CheckProportion));
    }];
    
    [self addSubview:self.volumePercentLa];
    [self.volumePercentLa mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_volumeImage);
        make.left.equalTo(_volumeprogreView.mas_right).offset(13 * CheckProportion);
        make.right.equalTo(self.smallVideoView.mas_right);
    }];
    
    
    [self addSubview:self.volumeReminderLa];
    
    [self.volumeReminderLa mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_volumeImage.mas_bottom).offset(15 * CheckProportion);
        make.left.equalTo(_volumeImage);
    }];
    
    
    
    // 确定按钮
    [self addSubview:self.sureBtn];
    
    [_sureBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_volumeReminderLa.mas_bottom).offset(80 * CheckProportion);
        make.centerX.equalTo(self);
        make.size.mas_equalTo(CGSizeMake(self.width - VIdeoHeight * 2 * CheckProportion, 44));
    }];
    
    
    if (IS_PAD) {
        [self addSubview:self.ConformDeviceReminderImg];
        [_ConformDeviceReminderImg mas_makeConstraints:^(MASConstraintMaker *make) {
           make.bottom.equalTo(_sureBtn.mas_top).offset(-30 * CheckProportion);
            make.left.equalTo(_videoStatusImg);
            make.size.mas_equalTo(CGSizeMake(16, 16));
        }];
        
        
        [self addSubview:self.ConformDeviceReminderLa];
        [_ConformDeviceReminderLa mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(_ConformDeviceReminderImg);
            make.left.equalTo(_ConformDeviceReminderImg.mas_right).offset(5);
            make.right.equalTo(self.smallVideoView.mas_right);
        }];
    }
    
    [self addSubview:self.isHiddenDeviceViewBtn];
    [_isHiddenDeviceViewBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_sureBtn.mas_bottom).offset(30 * CheckProportion);
        make.centerX.equalTo(self);
        make.size.mas_equalTo(CGSizeMake(400 * CheckProportion, 22));
    }];
    
    
    
}

#pragma mark - 横屏界面
- (void)setLandscapeRightUI {
    
    [self.videoTopTitleLa removeFromSuperview];
    [self.smallVideoView removeFromSuperview];
    [self.imageView removeFromSuperview];
    [self.preLayer removeFromSuperlayer];
    [self.videoStatusImg removeFromSuperview];
    [self.videoBottomTitleLa removeFromSuperview];
    [self.audioTitleLa removeFromSuperview];
    [self.audioView removeFromSuperview];
    [self.audioReminderLa removeFromSuperview];
    [self.volumeTitleLa removeFromSuperview];
    [self.volumeImage removeFromSuperview];
    [self.volumeprogreView removeFromSuperview];
    [self.volumeReminderLa removeFromSuperview];
    [self.sureBtn removeFromSuperview];
    [self.ConformDeviceReminderImg removeFromSuperview];
    [self.ConformDeviceReminderLa removeFromSuperview];
    
    
    self.frame = CGRectMake(0, 0, ScreenW, ScreenH);
    
    // 视频检测
    self.videoTopTitleLa.frame = CGRectMake( 110  * CheckProportion, IS_PAD ? 121 * CheckProportion : 30 * CheckProportion, 200, 30);
    [self addSubview:self.videoTopTitleLa];
    
    
    
    self.smallVideoView.frame = CGRectMake(110  * CheckProportion, IS_PAD ? 121 * CheckProportion + 45 : 30 * CheckProportion + 45, 373 * CheckProportion, 280 * CheckProportion);
    
    [self addSubview:self.smallVideoView];
    
    
    self.imageView.frame = self.smallVideoView.frame;
    [self addSubview:self.imageView];
    
    self.preLayer.frame = self.smallVideoView.frame;
    [self.layer addSublayer:self.preLayer];
    
    
    [self addSubview:self.videoStatusImg];
    [self.videoStatusImg mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_smallVideoView.mas_bottom).offset(12 * CheckProportion);
        make.left.equalTo(_smallVideoView);
        make.size.mas_equalTo(CGSizeMake(16 * CheckProportion, 16 * CheckProportion));
    }];
    
    
    [self addSubview:self.videoBottomTitleLa];
    
    [_videoBottomTitleLa mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_videoStatusImg);
        make.left.equalTo(_videoStatusImg.mas_right).offset(10 * CheckProportion);
        make.right.equalTo(self.smallVideoView.mas_right);
    }];
    
    
    if (IS_PAD) {
        [self addSubview:self.ConformDeviceReminderImg];
        [_ConformDeviceReminderImg mas_makeConstraints:^(MASConstraintMaker *make) {
           make.top.equalTo(_videoStatusImg.mas_bottom).offset(50 * CheckProportion);
            make.left.equalTo(_videoStatusImg);
            make.size.mas_equalTo(CGSizeMake(16, 16));
        }];
        
        
        [self addSubview:self.ConformDeviceReminderLa];
        [_ConformDeviceReminderLa mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(_ConformDeviceReminderImg);
            make.left.equalTo(_ConformDeviceReminderImg.mas_right).offset(5);
            make.right.equalTo(self.mas_right).offset(-30 * CheckProportion);
        }];
    }
    
    
        
    // 麦克风检测
    [self addSubview:self.audioTitleLa];
    
    [_audioTitleLa mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_videoTopTitleLa);
        make.left.equalTo(_smallVideoView.mas_right).offset(100 * CheckProportion);
    }];
    
    
    
    [self addSubview:self.audioView];
    [_audioView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_audioTitleLa.mas_bottom).offset(30 * CheckProportion);
        make.left.equalTo(_audioTitleLa.mas_left);
        make.size.mas_equalTo(CGSizeMake(225 * CheckProportion, 22 * CheckProportion));
    }];
    
    
    
    [self addSubview:self.audioReminderLa];
    [self.audioReminderLa mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_audioView.mas_bottom).offset(30 * CheckProportion);
        make.left.equalTo(_audioView);
        make.right.equalTo(self.mas_right).offset(-15 * CheckProportion);
    }];
    
    
    
    [self addSubview:self.microphoneOffReminderImg];
    [_microphoneOffReminderImg mas_makeConstraints:^(MASConstraintMaker *make) {
       make.top.equalTo(_audioReminderLa.mas_bottom).offset(15 * CheckProportion);
        make.left.equalTo(_audioReminderLa);
        make.size.mas_equalTo(CGSizeMake(16, 16));
    }];
    
    [self addSubview:self.microphoneOffReminderLa];
    [_microphoneOffReminderLa mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_microphoneOffReminderImg);
        make.left.equalTo(_microphoneOffReminderImg.mas_right).offset(5);
        make.right.equalTo(self.mas_right).offset(-15 * CheckProportion);
    }];
    
    
    
    // 扬声器检测
    [self addSubview:self.volumeTitleLa];
    
    [_volumeTitleLa mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_audioReminderLa.mas_bottom).offset(93 * CheckProportion);
        make.left.equalTo(_audioReminderLa);
    }];
    
    
    
    [self addSubview:self.volumeImage];
    
    [_volumeImage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_volumeTitleLa.mas_bottom).offset(30 * CheckProportion);
        make.left.equalTo(_volumeTitleLa.mas_left);
        make.size.mas_equalTo(CGSizeMake(23 * CheckProportion, 21 * CheckProportion));
    }];
    
    
    
    [self addSubview:self.volumeprogreView];
    
    [_volumeprogreView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_volumeImage);
        make.left.equalTo(_volumeImage.mas_right).offset(11 * CheckProportion);
        make.size.mas_equalTo(CGSizeMake(191 * CheckProportion, 5 * CheckProportion));
    }];
    
    
    [self addSubview:self.volumePercentLa];
    [self.volumePercentLa mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(_volumeImage);
        make.left.equalTo(_volumeprogreView.mas_right).offset(13 * CheckProportion);
    }];
    
    
    [self addSubview:self.volumeReminderLa];
    
    [self.volumeReminderLa mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_volumeImage.mas_bottom).offset(30 * CheckProportion);
        make.left.equalTo(_volumeImage);
        make.right.equalTo(self.mas_right).offset(-15 * CheckProportion);
    }];
    
    
    
    // 确定按钮
    [self addSubview:self.sureBtn];
    
    [_sureBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.mas_bottom).offset(IS_PAD ? -108 * CheckProportion : -60 * CheckProportion);
        make.centerX.equalTo(self);
        make.size.mas_equalTo(CGSizeMake(490 * CheckProportion, 44));
    }];
    
    [self addSubview:self.isHiddenDeviceViewBtn];
    [_isHiddenDeviceViewBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_sureBtn.mas_bottom).offset(IS_PAD ? 44 * CheckProportion : 15 * CheckProportion);
        make.centerX.equalTo(self);
        make.size.mas_equalTo(CGSizeMake(300 * CheckProportion, 22));
    }];
    
}



- (void)creatVideo {
    
    if (self.preLayer) {
        [self.preLayer removeFromSuperlayer];
        self.preLayer = nil;
    }
    
    NSError *error = nil;
    session = [[AVCaptureSession alloc] init] ;
    session.sessionPreset = AVCaptureSessionPresetMedium;
    AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:[self frontCamera] error:&error];
    if (!input) {
        self.videoStatusImg.image = [UIImage imageNamed:@"tk_deviceCheck_cameraOff"];
        self.videoBottomTitleLa.text = TKMTLocalized(@"TKDeviceCheck.CameraOffReminder");
        self.videoBottomTitleLa.textColor = RGBCOLOR(255, 82, 82);
        return;
    }
    
    [session addInput:input];
    
    AVCaptureVideoDataOutput *output = [[AVCaptureVideoDataOutput alloc] init];
    [session addOutput:output];
    
    dispatch_queue_t queue = dispatch_queue_create("myQueue", NULL);
    [output setSampleBufferDelegate:self queue:queue];
    
    output.videoSettings = [NSDictionary dictionaryWithObjectsAndKeys:
    [NSNumber numberWithInt:kCVPixelFormatType_32BGRA], kCVPixelBufferPixelFormatTypeKey,
    [NSNumber numberWithInt: 320], (id)kCVPixelBufferWidthKey,
    [NSNumber numberWithInt: 240], (id)kCVPixelBufferHeightKey, nil];
    
    
    self.preLayer = [AVCaptureVideoPreviewLayer layerWithSession:session];
    
    self.preLayer.frame = self.smallVideoView.frame;
    self.preLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    [self.layer addSublayer:self.preLayer];
    
    [session startRunning];
}

#pragma mark - 视频相关
//返回前置摄像头
- (AVCaptureDevice *)frontCamera {
    return [self cameraWithPosition:AVCaptureDevicePositionFront];
}

- (AVCaptureDevice *)cameraWithPosition:(AVCaptureDevicePosition) position {
    //返回和视频录制相关的所有默认设备
    NSArray *devices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    //遍历这些设备返回跟position相关的设备
    for (AVCaptureDevice *device in devices) {
        if ([device position] == position) {
            return device;
        }
    }
    return nil;
}


#pragma mark - mark 创建录音
- (void)creatAudioSession {
    
    // 麦克风状态的检测
    AVAuthorizationStatus microPhoneStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio];
    
    switch (microPhoneStatus) {
        case AVAuthorizationStatusDenied:
        case AVAuthorizationStatusRestricted: {
            // 被拒绝
            self.microphoneOffReminderImg.hidden = NO;
            self.microphoneOffReminderLa.hidden = NO;
        }
            break;
        default:
            break;
    }
    
    recorder = nil;
    
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord withOptions:AVAudioSessionCategoryOptionDefaultToSpeaker | AVAudioSessionCategoryOptionMixWithOthers | AVAudioSessionCategoryOptionAllowBluetooth error:nil];
        /* 不需要保存录音文件 */
        NSURL *url = [NSURL fileURLWithPath:@"/dev/null"];
        
        NSDictionary *settings = [NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithFloat:44100], AVSampleRateKey,[NSNumber numberWithInt: kAudioFormatAppleLossless], AVFormatIDKey, [NSNumber numberWithInt: 2], AVNumberOfChannelsKey, [NSNumber numberWithInt: AVAudioQualityMax], AVEncoderAudioQualityKey, nil];
    
        NSError *error;
        recorder = [[AVAudioRecorder alloc] initWithURL:url settings:settings error:&error];
        if (recorder){
            [recorder prepareToRecord];
            //开启分贝监听
            recorder.meteringEnabled = YES;
            [recorder record];
            //定时获取分贝
            levelTimer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector: @selector(levelTimerCallback:) userInfo:nil repeats:YES];
        }else{
            NSLog(@"%@", [error description]);
        }
}



#pragma mark - 检测麦克风
- (void)levelTimerCallback:(NSTimer *)timer {
    
    // 系统音量实时检测
    CGFloat currentVol = self.audioSession.outputVolume;
    
    self.volumeprogreView.progress = currentVol;
    if (currentVol == 0) {
        self.volumePercentLa.hidden = YES;
        self.volumeImage.image = [UIImage imageNamed:@"tk_deviceCheck_volume_selected"];
    }else {
        self.volumePercentLa.hidden = NO;
        NSString *percentString = [NSString stringWithFormat:@"%f", currentVol * 100];
        NSArray *array = [percentString componentsSeparatedByString:@"."];
        self.volumePercentLa.text = [NSString stringWithFormat:@"%@%%", array[0]];
        self.volumeImage.image = [UIImage imageNamed:@"tk_deviceCheck_volume_default"];
    }
    
    
    
    [recorder updateMeters];//刷新音量数据
    //获取分贝  基本在0-1之间 可能超过1
    CGFloat lowPassResults = pow(10, (0.05 * [recorder peakPowerForChannel:0]));
 //分成10个等级
    
//    NSLog(@"voice updated :%f",lowPassResults);
    int lastVolume = 0;
    if (lowPassResults <= 0.03) {
        lastVolume = 0;
    }else if (lowPassResults <= 0.06) {
        lastVolume = 1;
    }else if (lowPassResults <= 0.13) {
        lastVolume = 2;
    }else if (lowPassResults <= 0.2) {
        lastVolume = 3;
    }else if (lowPassResults <= 0.27) {
        lastVolume = 4;
    }else if (lowPassResults <= 0.35) {
        lastVolume = 5;
    }else if (lowPassResults <= 0.40) {
        lastVolume = 6;
    }else if (lowPassResults <= 0.50) {
        lastVolume = 7;
    }else if (lowPassResults <= 0.60) {
        lastVolume = 8;
    }else if (lowPassResults <= 0.76) {
        lastVolume = 9;
    }else if (lowPassResults <= 0.88) {
        lastVolume = 10;
    }
    
    self.audioView.image = [UIImage imageNamed:[NSString stringWithFormat:@"tk_ microphone_%d", lastVolume]];
    
    
}


- (void)HiddenDeviceViewBtnAction:(UIButton *)sender {
    sender.selected = !sender.selected;
    if (sender.selected) {
        [[NSUserDefaults standardUserDefaults] setObject:@"1" forKey:@"isShowDeveiceCheckView"];
    }else {
        [[NSUserDefaults standardUserDefaults] setObject:@"0" forKey:@"isShowDeveiceCheckView"];
    }
}



- (UIButton *)isHiddenDeviceViewBtn {
    if (!_isHiddenDeviceViewBtn) {
        _isHiddenDeviceViewBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_isHiddenDeviceViewBtn setImage:[UIImage imageNamed:@"tk_checkDevice_isShow_default"] forState:UIControlStateNormal];
        [_isHiddenDeviceViewBtn setImage:[UIImage imageNamed:@"tk_checkDevice_isShow_selected"] forState:UIControlStateSelected];
        [_isHiddenDeviceViewBtn setTitle:TKMTLocalized(@"TKDeviceCheck.isShowDeviceCheckView") forState:UIControlStateNormal];
        [_isHiddenDeviceViewBtn setTitle:TKMTLocalized(@"TKDeviceCheck.isShowDeviceCheckView") forState:UIControlStateSelected];
        _isHiddenDeviceViewBtn.titleLabel.font = [UIFont systemFontOfSize:15 * CheckProportion];
        [_isHiddenDeviceViewBtn setTitleColor:RGBCOLOR(55, 55, 55) forState:UIControlStateNormal];
        [_isHiddenDeviceViewBtn setTitleColor:RGBCOLOR(55, 55, 55) forState:UIControlStateSelected];
        _isHiddenDeviceViewBtn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        [_isHiddenDeviceViewBtn setTitleEdgeInsets:UIEdgeInsetsMake(_isHiddenDeviceViewBtn.imageView.frame.size.height ,_isHiddenDeviceViewBtn.imageView.frame.size.width + 11, 0.0,0.0)];
        [_isHiddenDeviceViewBtn addTarget:self action:@selector(HiddenDeviceViewBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        _isHiddenDeviceViewBtn.selected = YES;
    }
    return _isHiddenDeviceViewBtn;
}

- (void)sureButtonDidClicked {
    
    [recorder stop];
    recorder = nil;
    [levelTimer invalidate];
    levelTimer = nil;
    [session stopRunning];
    
    [self removeFromSuperview];
    
    if (self.confirmBlock) {
        self.confirmBlock();
    }
    
}

- (void)dealloc {
    [recorder stop];
    [levelTimer invalidate];
    levelTimer = nil;
    [session stopRunning];
}


#pragma mark - 懒加载

- (UIImageView *)ConformDeviceReminderImg {
    if (!_ConformDeviceReminderImg) {
        _ConformDeviceReminderImg = [[UIImageView alloc] init];
        _ConformDeviceReminderImg.image = [UIImage imageNamed:@"tk_conformDevice"];
        _ConformDeviceReminderImg.hidden = YES;
    }
    return _ConformDeviceReminderImg;
}


- (UILabel *)ConformDeviceReminderLa {
    if (!_ConformDeviceReminderLa) {
        _ConformDeviceReminderLa = [[UILabel alloc] init];
        _ConformDeviceReminderLa.font = [UIFont systemFontOfSize:14 * CheckProportion];
        _ConformDeviceReminderLa.textColor = RGBCOLOR(255, 82, 82);
        _ConformDeviceReminderLa.hidden = YES;
        _ConformDeviceReminderLa.numberOfLines = 0;
    }
    return _ConformDeviceReminderLa;
}


- (UIImageView *)microphoneOffReminderImg {
    if (!_microphoneOffReminderImg) {
        _microphoneOffReminderImg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"tk_deviceCheck_cameraOff"]];
        _microphoneOffReminderImg.hidden = YES;
    }
    return _microphoneOffReminderImg;
}


- (UILabel *)microphoneOffReminderLa {
    if (!_microphoneOffReminderLa) {
        _microphoneOffReminderLa = [[UILabel alloc] init];
        _microphoneOffReminderLa.text = TKMTLocalized(@"TKDeviceCheck.MicrophoneOffReminder");
        _microphoneOffReminderLa.font = [UIFont systemFontOfSize:14 * CheckProportion];
        _microphoneOffReminderLa.textColor = RGBCOLOR(255, 82, 82);
        _microphoneOffReminderLa.hidden = YES;
        _microphoneOffReminderLa.numberOfLines = 0;
    }
    return _microphoneOffReminderLa;
}

- (UIImageView *)videoStatusImg {
    if (!_videoStatusImg) {
        _videoStatusImg = [[UIImageView alloc] init];
        _videoStatusImg.image = [UIImage imageNamed:@"tk_deviceCheck_cameraOn"];
    }
    return _videoStatusImg;
}

- (UILabel *)audioReminderLa {
    if (!_audioReminderLa) {
        _audioReminderLa = [[UILabel alloc] init];
        _audioReminderLa.font = [UIFont systemFontOfSize:16 * CheckProportion];
        _audioReminderLa.text = TKMTLocalized(@"TKDeviceCheck.MicrophoneReminder");
        _audioReminderLa.numberOfLines = 0;
        _audioReminderLa.textColor = UIColor.blackColor;
    }
    return _audioReminderLa;
}

- (UILabel *)volumePercentLa {
    if (!_volumePercentLa) {
        _volumePercentLa = [[UILabel alloc] init];
        _volumePercentLa.textColor = RGBACOLOR(0, 119, 255, 1);
    }
    return _volumePercentLa;
}

- (UILabel *)volumeReminderLa {
    if (!_volumeReminderLa) {
        _volumeReminderLa = [[UILabel alloc] init];
        _volumeReminderLa.font = [UIFont systemFontOfSize:16 * CheckProportion];
        _volumeReminderLa.text = TKMTLocalized(@"TKDeviceCheck.SpeakerReminder");
        _volumeReminderLa.numberOfLines = 0;
        _volumeReminderLa.textColor = UIColor.blackColor;
    }
    return _volumeReminderLa;
}

- (UIImageView *)imageView {
    if (!_imageView) {
        _imageView = [[UIImageView alloc] init];
        _imageView.image = [UIImage imageNamed:@"tk_deveiceCheck_NoCamera"];
    }
    return _imageView;
}


- (UILabel *)videoTopTitleLa {
    if (!_videoTopTitleLa) {
        _videoTopTitleLa = [[UILabel alloc] init];
        _videoTopTitleLa.text = TKMTLocalized(@"TKDeviceCheck.VideoPreview");
        _videoTopTitleLa.textColor = UIColor.blackColor;
        _videoTopTitleLa.font = [UIFont systemFontOfSize:25 * CheckProportion];
    }
    return _videoTopTitleLa;
}

- (UIView *)smallVideoView {
    if (!_smallVideoView) {
        _smallVideoView = [[UIView alloc] init];
    }
    return _smallVideoView;
}

- (UILabel *)videoBottomTitleLa {
    if (!_videoBottomTitleLa) {
        _videoBottomTitleLa = [[UILabel alloc] init];
        _videoBottomTitleLa.text = TKMTLocalized(@"TKDeviceCheck.CameraOnReminder");
        _videoBottomTitleLa.font = [UIFont systemFontOfSize:16 * CheckProportion];
        _videoBottomTitleLa.numberOfLines = 0;
        _videoBottomTitleLa.textColor = UIColor.blackColor;
    }
    return _videoBottomTitleLa;
}



- (UILabel *)audioTitleLa {
    if (!_audioTitleLa) {
        _audioTitleLa = [[UILabel alloc] init];
        _audioTitleLa.text = TKMTLocalized(@"TKDeviceCheck.MicrophoneTest");
        _audioTitleLa.textColor = UIColor.blackColor;
        _audioTitleLa.font = [UIFont systemFontOfSize:25 * CheckProportion];
    }
    return _audioTitleLa;
}

- (UIImageView *)audioView {
    if (!_audioView) {
        _audioView = [[UIImageView alloc] init];
        _audioView.image = [UIImage imageNamed:@"tk_ microphone_0"];
    }
    return _audioView;
}

- (UILabel *)volumeTitleLa {
    if (!_volumeTitleLa) {
        _volumeTitleLa = [[UILabel alloc] init];
        _volumeTitleLa.text = TKMTLocalized(@"TKDeviceCheck.SpeakerTest");
        _volumeTitleLa.textColor = UIColor.blackColor;
        _volumeTitleLa.font = [UIFont systemFontOfSize:25 * CheckProportion];
    }
    return _volumeTitleLa;
}

- (UIProgressView *)volumeprogreView {
    if (!_volumeprogreView) {
        _volumeprogreView = [[UIProgressView alloc] init];
        _volumeprogreView.progressTintColor = RGBACOLOR(0, 119, 255, 1);
    }
    return _volumeprogreView;
}

- (UIImageView *)volumeImage {
    if (!_volumeImage) {
        _volumeImage = [[UIImageView alloc] init];
        _volumeImage.image = [UIImage imageNamed:@"tk_deviceCheck_volume_default"];
    }
    return _volumeImage;
}

- (UIButton *)sureBtn {
    if (!_sureBtn) {
        _sureBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [_sureBtn setTitle:TKMTLocalized(@"TKDeviceCheck.Ecter") forState:UIControlStateNormal];
        _sureBtn.backgroundColor = RGBACOLOR(0, 119, 255, 1);
//        [_sureBtn setBackgroundImage:[UIImage imageNamed:@"tk_bt_join_room_bg"] forState:UIControlStateNormal];
        _sureBtn.layer.cornerRadius = 22;
        [_sureBtn addTarget:self action:@selector(sureButtonDidClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return _sureBtn;
}

@end








