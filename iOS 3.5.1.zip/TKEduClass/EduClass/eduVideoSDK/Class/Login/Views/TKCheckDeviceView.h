//
//  TKCheckDeviceView.h
//  EduClass
//
//  Created by Evan on 2020/4/13.
//  Copyright © 2020 talkcloud. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TKCheckDeviceView : UIView

@property (nonatomic, copy) dispatch_block_t confirmBlock;

@end


NS_ASSUME_NONNULL_END
