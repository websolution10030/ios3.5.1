//
//  TKLoginSettingView.h
//  EduClass
//
//  Created by Evan on 2020/3/24.
//  Copyright © 2020 talkcloud. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TKLoginSettingView : UIView
- (void)show:(UIView *)view;
@end

NS_ASSUME_NONNULL_END
