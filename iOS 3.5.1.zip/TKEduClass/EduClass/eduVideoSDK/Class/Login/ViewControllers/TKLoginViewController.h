//
//  TKLoginViewController.h
//  EduClass
//
//  Created by lyy on 2018/4/17.
//  Copyright © 2018年 beijing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TKBaseViewController.h"
#import "TKEduClassRoom.h"

@interface TKLoginViewController : UIViewController<TKEduRoomDelegate>

@end
