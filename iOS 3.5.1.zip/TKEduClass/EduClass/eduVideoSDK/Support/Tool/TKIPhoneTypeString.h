//
//  IPhoneTypeString.h
//  xydspace
//
//  Created by 心意答 on 16/12/12.
//  Copyright © 2016年 LYP. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TKIPhoneTypeString : NSObject

+(NSString *)checkIPhoneType;


@end
