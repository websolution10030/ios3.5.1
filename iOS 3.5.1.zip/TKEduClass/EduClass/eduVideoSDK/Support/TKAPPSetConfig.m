//
//  TKAPPSetConfig.m
//  EduClass
//
//  Created by maqihan on 2018/11/30.
//  Copyright © 2018 talkcloud. All rights reserved.
//

#import "TKAPPSetConfig.h"
#import "LTUpdate.h"
#import <Bugly/Bugly.h>
#import "TKLoginViewController.h"

// 崩溃日志
//#define CRASH_REPORT_ADDRESS    @"https://global.talk-cloud.com/update/public"
//#define CRASH_REPORT_ADDRESS    @"http://doc.talk-cloud.net/update/reports/?C=M;O=D"
#define BuglyID					@"9950489142"

@interface TKAPPSetConfig ()

@end

@implementation TKAPPSetConfig

+ (instancetype)shareInstance {
    static TKAPPSetConfig *_sharedManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedManager = [[TKAPPSetConfig alloc] init];
    });
    return _sharedManager;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (void)setLoginViewForRootViewController:(UIWindow *) window {
    
    NSAssert(window, @"setLoginViewForRootViewController: window was nil");
    
    TKLoginViewController * loginVC = [[TKLoginViewController alloc] init];
    UINavigationController * nav = [[UINavigationController alloc] initWithRootViewController:loginVC];
    [nav.navigationBar setHidden:YES];
    window.rootViewController = nav;
}

- (void)setupAppTheme {
    
    //设置主题
    NSArray * sakuraArray = @[TKCartoonSkin,TKBlackSkin,TKOrangeSkin];
    [TXSakuraManager registerLocalSakuraWithNames:sakuraArray];
    
    //切换到默认主题
    NSString *name = [TXSakuraManager getSakuraCurrentName];
    NSInteger type = [TXSakuraManager getSakuraCurrentType];
    if (![sakuraArray containsObject:name]) {
        name = TKCartoonSkin;// 防止 新版本更换皮肤名字后 用户打开app闪退
        type = TXSakuraTypeMainBundle;
    }
    [TXSakuraManager shiftSakuraWithName:name type:type];
}


- (void)setupAPPWithBuglyID:(NSString *)buglyId
{
    // Bugly崩溃日志
    if (buglyId.length == 0 || buglyId == nil) {
        buglyId = BuglyID;
    }
    [Bugly startWithAppId:buglyId];
    
}

//检测版本升级
- (void)checkForUpdate
{
    
    LTUpdate *upd = (LTUpdate*)[LTUpdate shared];
    [upd clearSkippedVersion];
    [upd update:100 complete:^(BOOL isNewVersionAvailable, LTUpdateVersionDetails *__unused versionDetails) {
        
        if (isNewVersionAvailable) {
            
            [TKEduNetManager getupdateinfoWithaHost:sHost
                                              aPort:sPort
                                            Version:UpdateVersion
                                               Type:5
                                           Complete:^int(id  _Nullable response)
             {
                if ([response[@"result"] intValue] != -1) {
                    int updateflag = [response[@"updateflag"] intValue];
                    
                    switch (updateflag) {
                        case 0://不强制
                            break;
                        case 1://强制升级
                            [upd alertForcedToUpdateLatestVersion:LTUpdateOption];
                            break;
                        case 2://有条件升级
                            [upd alertLatestVersion:LTUpdateOption | LTUpdateSkip];
                            break;
                        default:
                            break;
                    }
                }
                [[NSNotificationCenter defaultCenter] postNotificationName : @"CheckVersionFinish"  object:nil];
                
                return 0;
                
                
            }
                                          aNetError:^int(id  _Nullable response)
             {
                
                [[NSNotificationCenter defaultCenter] postNotificationName : @"CheckVersionFinish"  object:nil];
                
                return -1;
            }];
        }
        else {
            
            [[NSNotificationCenter defaultCenter] postNotificationName : @"CheckVersionFinish"  object:nil];
        }
        
    }];
    
    
}

@end
