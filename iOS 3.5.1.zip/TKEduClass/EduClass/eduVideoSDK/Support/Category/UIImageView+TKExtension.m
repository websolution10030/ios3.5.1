//
//  UIImageView+DJExtension.m
//  EduClass
//
//  Created by lyy on 2018/5/4.
//  Copyright © 2018年 talkcloud. All rights reserved.
//

#import "UIImageView+TKExtension.h"

static NSArray* gifImagesArray;
static NSString* gifPath;

@implementation UIImageView (TKExtension)

// 播放GIF
- (void)tkPlayGifAnim:(NSArray *)images
{
    if (!images.count) {
        return;
    }
    //动画图片数组
    self.animationImages = images;
    //执行一次完整动画所需的时长
    self.animationDuration = images.count/10.0;
    //动画重复次数, 设置成0 就是无限循环
    self.animationRepeatCount = 0;
    [self startAnimating];
}
// 停止动画
- (void)tkStopGifAnim
{
    if (self.isAnimating) {
        [self stopAnimating];
    }
    self.animationImages = nil;
    gifImagesArray = nil;
}

+ (NSArray *)tkGetImagesWithGifName:(NSString *)name path:(NSString *)path{
    
    if ([path isEqualToString:gifPath] && gifImagesArray.count > 0) {
        return gifImagesArray;
    }
    
    if (path.length <= 0) {
        return nil;
    }
    
    CGImageSourceRef source = CGImageSourceCreateWithURL((CFURLRef)[NSURL fileURLWithPath:path], NULL);
    size_t count = CGImageSourceGetCount(source);
    
    NSMutableArray *imageArray = [NSMutableArray arrayWithCapacity:count];
    
    for (size_t i=0; i<count; i++) {
        
        CGImageRef image = CGImageSourceCreateImageAtIndex(source, i, NULL);

        if (image == NULL) {
            break;
        }
        [imageArray addObject:[UIImage imageWithCGImage:image]];

        CGImageRelease(image);
    }
    CFRelease(source);
    
    gifImagesArray = [NSArray arrayWithArray:imageArray];
    imageArray = nil;
    
    gifPath = path;
    
    return gifImagesArray;
}

@end
