
1. *工程结构*

iOS UI SDK中有1个文件夹:eduVideoSDK
- 1.1.1 eduVideoSDK 主文件夹 ：     
- handle（包含TKEduClassRoom（课堂SDK接口类文件）等处理课堂逻辑）
- Base（基类）
- Support（辅助类）
- Class（界面层，model数据）
- Vendor（第三方引用文件）
- libs（需要引用的库）包括: 
1.TKRoomSDK.framework  课堂sdk 
2.TKWhiteBoard.framework 白板sdk   
3.RevealServer.framework UI调试工具  可选择删除或保留.

- 1.1.2 Resource（引用的资源以及模板资源）

2. 配置工程文件
- 2.1.设置
- Build Phases->Copy FIles(Embed Frameworks)->Destination->选择为Frameworks
- Build Phases->Copy FIles(Embed Frameworks)->name->添加TKRoomSDK.framework
- Build Settings -> Linking ->Other Linker Flags -> -Objc


- 2.2 添加库
- Build Phases->Link Binary With Libraries-> 
.......详见工程

- 2.3 添加动态库

- General->Embedded Binaries->TKRoomSDK.framework

- 2.4 取消Bitcode

- Build Settings->Build Options->Enable Bitcode->设置为NO

- 2.5 设置语言

- 如果显示中文，请在infoPlist中，修改Localization native development region为China。

- 2.6 设置权限
- info.plist -> Privacy - Camera Usage Description        ->  教室中需要进行视频通话以及拍摄您是否允许打开相机
- info.plist -> Privacy - Microphone Usage Description    -> 教室中需要发送语音消息及发言您是否允许打开麦克风
- info.plist -> Privacy - Photo Library Usage Description ->  教室中需要选择本地图片您是否允许访问相册
- info.plist -> Privacy - Photo Library Additions Usage Description -> 教室中需要上传图片您是否允许添加图片
- info.plist ->App Transport Security Settings->Allow Arbitrary Loads->YES

- 2.7 适配MRC文件

- Build Phases->Compile Sources->TKGTMBase64  ->  -fno-objc-arc

- 2.8 在PrefixHeader.pch中添加对应(头文件.h)，参照UISDK  TKPrefixHeader.pch文件

- 2.9 Pods添加以来第三方库(部分)
查看工程已添加三方版本号, 可修改pod.lock 文件后缀为txt
```objective-c
pod 'SSZipArchive'
pod 'SDWebImage', '~> 4.0'
pod 'HockeySDK'
```
- 2.10 添加皮肤相关文件
- Assets.xcassets 中的图片
- Resource 文件夹下   *.json  主题文件

- 2.11 主题代码初始化，在joinroom之前设置即可

```objective-c

//设置主题  使用 TXSakuraKit 三方库.
NSArray * sakuraArray = @[TKCartoonSkin,TKBlackSkin];
[TXSakuraManager registerLocalSakuraWithNames:sakuraArray];

//切换到默认主题
NSString *name = [TXSakuraManager getSakuraCurrentName];
NSInteger type = [TXSakuraManager getSakuraCurrentType];
if (![sakuraArray containsObject:name]) {
name = TKCartoonSkin;// 防止 新版本更换皮肤名字后 用户打开app闪退
type = TXSakuraTypeMainBundle;
}
[TXSakuraManager shiftSakuraWithName:name type:type];

```
- 2.12 Build Settings -> Build Options -> Always Embed Swift Standard Libraries （若项目中未引用swift库，请设置为NO）

3.函数介绍

- 3.1    进入房间的函数：

```objective-c

+(int)joinRoomWithParamDic:(NSDictionary*)paramDic
ViewController:(UIViewController*)controller
Delegate:(id<TKEduRoomDelegate>)delegate
isFromWeb:(BOOL)isFromWeb;
```
- **参数详解**：
- paramDic: 

- NSDictionary类型，键值需要传递serial（课堂号）、host（服务器地址）、port（服务器端口号http 对应80, https 对应443）、nickname（用户昵称）、userrole(用户身份，0老师 1助教 2学生  4巡课)、userid(用户ID，可选)、server(global)、password(密码,可选)、clientType（设备类型1 PC 2 Android 3 iOS)

- controller:

-  当前页面的控制器，通常与下边delegate相同

- delegate: 

- 遵循TKEduRoomDelegate代理，供给用户进行处理

- isFromWeb: 

- 是否是从网址链接进入

​
​
​- 例子1 直接调用
​
​
​```objective-c
​
​NSDictionary *tDict = @{ @"serial" :@"595613855",
​@"host" :@"global.talk-cloud.net",
​@"port" :@"80",
​@"userrole" @(2),
​@"server": @"global",
​@"userid"  : @"1111",//可选
​@"password":@"1",//可选
​@"clientType":@(3),
​@"nickname":@"xiaoming"
​};
​[TKEduClassRoom joinRoomWithParamDic:tDict ViewController:self Delegate:self isFromWeb:NO];
​
​```
​
​- 例子2 从网页调用
​
​```objective-c
​
​//2.1 AppDelegate中
​#if defined(__IPHONE_OS_VERSION_MAX_ALLOWED) && __IPHONE_OS_VERSION_MAX_ALLOWED >= 90000
​-(BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options{
​
​[[TKEduClassRoom shareInstance] joinRoomWithUrl:url.relativeString];
​return YES;
​}
​
​#else
​
​- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(nullable NSString *)sourceApplication annotation:(id)annotation{
​
​return YES;
​}
​#endif
​
​
​//2.2 调用 TKEduClassRoom.m 中函数
​#pragma mark - 通过链接进入教室
​-(void)joinRoomWithUrl:(NSString*)url
​{
​self.url = url;
​//此时正在课堂中,需要退出
​if (self.classStatus != EClassStatus_IDLE) {
​
​self.enterClassRoomAgain = YES;
​
​if (_roomJson.roomtype != TKRoomTypeOneToOne) {
​
​[_ctMoreController prepareForLeave:YES];
​
​}else{
​[_ctOneController prepareForLeave:YES];
​}
​
​}else{
​
​[self openUrl:self.url];
​}
​}
​```
​
​- 3.2 .进入房间时的回调代理
​```objective-c
​
​@protocol TKEduEnterClassRoomDelegate <NSObject>
​
​```
​- 3.2.1 进入房间失败
​
​```objective-c
​
​- (void) onEnterRoomFailed:(int)result Description:(NSString*)desc;
​
​```
​
​- 参数详解：
​
​- result:
​- 4008 密码错误
​- 4110 需要密码
​- 4007 课堂不存在
​- 3001 服务器过期
​- 3002  公司被冻结
​- 3003 课堂被删除或过期
​- 4109 认证错误
​- 4103 房间人数超限
​- desc：
​- 失败的原因描述
​
​​
​​
​​- 3.2.2 被踢回调
​​
​​```objective-c
​​- (void) onKitout:(EKickOutReason)reason;
​​```
​​
​​- 参数详解：
​​- reason:
​​-  0:被老师踢出（暂时无） 1：重复登录
​​- 3.2.3 进入课堂成功后的回调
​​
​​```objective-c
​​- (void) joinRoomComplete
​​```
​​
​​- 3.2.4 离开课堂成功后的回调
​​
​​```objective-c
​​- (void) leftRoomComplete
​​```
​​
​​- 3.2.5 课堂开始的回调
​​
​​```objective-c
​​- (void) onClassBegin;
​​```
​​
​​
​​- 3.2.6 课堂结束的回调
​​
​​```objective-c
​​- (void) onClassDismiss;
​​```
​​
​​
​​- 3.2.7 摄像头打开失败回调
​​
​​```objective-c
​​- (void) onCameraDidOpenError;
​​```
​​
​​
​​- 3.3 离开课堂
​​
​​```objective-c
​​
​​+(void)leftRoom;
​​
​​```
​​
​​- 3.4 进入回放房间的函数:
​​
​​```objective-c
​​+ (int)joinPlaybackRoomWithParamDic:(NSDictionary *)paramDic
​​ViewController:(UIViewController*)controller
​​Delegate:(id<TKEduRoomDelegate>)delegate
​​isFromWeb:(BOOL)isFromWeb;
​​```
​​
​​参数详解：
​​
​​​
​​​
​​​- paramDic: 
​​​- NSDictionary类型，键值需要传递serial（课堂号）、host（服务器地址）、port（服务器端口号）、path（回放参数，具体看播放回放的文件）、playback(是否是回放，YES)、type(房间类型 0 1v1 3 1v多 10直播 11伪直播 12 旁路直播 )，clientType（设备类型 1 PC 2 Android 3 iOS）
​​​- controller:
​​​- 当前页面的控制器，通常与下边delegate相同
​​​- delegate: 
​​​- 遵循TKEduRoomDelegate代理，供给用户进行处理
​​​- isFromWeb: 
​​​- 是否是从网址链接进入进入 YES, (**如果传入NO 会启动角色密码检测**)
​​​
​​​- 例子 ：与进入房间相类似
​​​
​​​
​​​
​​​4.流程
​​​
​​​- 调用joinRoomWithParamDic 函数或者joinPlaybackRoomWithParamDic
​​​
​​​1. 进入课堂成功：返回joinRoomComplete回调
​​​2. 进入课堂失败：
​​​1. 需要密码、密码错误等，返回onEnterRoomFailed：Description回调
​​​2. 摄像头打开失败 ，返回onCameraDidOpenError回调
​​​
​​​​
​​​​
​​​​5.注意事项
​​​​
​​​​- 5.1 注意参数大小写
​​​​- 5.2 教室只支持横屏，所以需要项目支持横屏状态Landscape Right
​​​​- 5.3 如果遇到其他音视频第三方SDK出现问题，需要联系我们。
​​​​
​​​​6.FAQ
​​​​
​​​​- Q:SDK支持哪些CPU版本？
​​​​- A:iOS SDK目前支持 armv7、arm64、x86_64
​​​​
​​​​- Q:为什么没有课件？
​​​​- A:有可能是是1.1.2步骤没有操作，白板资源文件没有导入
​​​​
​​​​- Q:Xcode打包报错Unsupported Architecture？
​​​​- A: 
​​​​- 因为上传appsotre不能包含x86等模拟器结构，所以需要去掉。下边三选一
​​​​
​​​​- 将rmX86.sh的内容添加到Run Script 中在打包
​​​​- 或者直接用“SDK”文件夹下的"真机framework"
​​​​- 用命令行去除TKRoomSDK中x86结构（TKWhiteBoard）
​​​​- 进入到TKRoomSDK.framework内
​​​​- lipo TKRoomSDK -thin arm64 -output TKRoomSDK_arm64
​​​​- lipo TKRoomSDK -thin armv7 -output TKRoomSDK_armv7
​​​​- lipo -create TKRoomSDK_armv7 TKRoomSDK_arm64 -output TKRoomSDK
​​​​- rm TKRoomSDK_arm64
​​​​- rm TKRoomSDK_armv7
​​​​- 命令行去除TKWhiteBoard中x86结构
​​​​- 进入到TKWhiteBoard.framework内
​​​​- lipo TKWhiteBoard -thin arm64 -output TKWhiteBoard_arm64
​​​​- lipo TKWhiteBoard -thin armv7 -output TKWhiteBoard_armv7
​​​​- lipo -create TKWhiteBoard_armv7 TKWhiteBoard_arm64 -output TKWhiteBoard
​​​​- rm TKWhiteBoard_arm64
​​​​- rm TKWhiteBoard_armv7
​​​​
​​​​
​​​​
​​​​
​​​​
​​​​
​​​​
​​​​
